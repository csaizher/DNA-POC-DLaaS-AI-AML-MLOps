

class MLOComputeConstants:
    """Constants used for the MLOData module.

    Values:
        DEFAULT_VM_SIZE ([str]): VM Size type when greate a compute cluser
        DEFAULT_IDLE_SECONDS_BEFORE_SCALE_DOWN ([int]): Node idle time in
            seconds before scaling down the cluster when create a compute
            cluster. @See
            https://docs.microsoft.com/en-us/python/api/azureml-core/azureml
            .core.compute.amlcompute(class)?view=azure-ml-py
        DEFAULT_VM_ADMIN_USER ([str]): Default admin user for the created VM
    """
    DEFAULT_VM_SIZE = "STANDARD_D64_v3"
    DEFAULT_IDLE_SECONDS_BEFORE_SCALE_DOWN = 3000
    DEFAULT_VM_ADMIN_USER = "azureuser"

    DEFAULT_MIN_NODES_TRAINING = 0
    DEFAULT_MAX_NODES_TRAINING = 1
    DEFAUlT_VM_SIZE_TRAINING = "STANDARD_D64_v3"

    DEFAULT_COMPUTE_INSTANCE_PROFILE_NAME = "profile-default"

    # Just use a computer cluster
    COMPUTE_CLUSTER_TYPE_CLUSTER = "cluster"
    # Do not use compute cluster, use a computer instance
    COMPUTE_CLUSTER_TYPE_CI = "ci"
