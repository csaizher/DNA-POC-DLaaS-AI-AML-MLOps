import uuid
from enum import Enum
import sys, traceback
from azureml.core.compute import ComputeTarget, AmlCompute
from azureml.core.compute_target import ComputeTargetException
from .mlocompute_constants import MLOComputeConstants


class ClusterProcessType(Enum):
    """List of possible cluster processes types for Azure ML.

    Values:
        TRAIN ([int]): Cluster used for training. It represents a process
            AzureML cluster.
        DEPLOY ([int]): Cluster used for inference. It represents an inference
            AzureML cluster.
        PROFILE ([int]): Cluster used for data profiling. It represents an
            inference AzureML cluster.
        INVALID ([int]): Not valid cluster.
    """
    TRAIN = 1
    DEPLOY = 2
    PROFILE = 3
    INVALID = 0


class MLOCompute:

    @staticmethod
    def generateClusterProcessName(cluster_type):
        """Generate a name for the cluster

        Note:The cluster can include letters, digits and dashes and a maximum
        length of 16 chars.

        Args:
        cluster_type ([ClusterProcessType]): type of the cluster.

        Returns:
        cluster_name: Name of the cluster
        """

        # By default invalid cluster type
        cluster_name = "invalid-" + str(uuid.uuid1())

        if cluster_type == ClusterProcessType.DEPLOY:
            cluster_name = "deploy-" + str(uuid.uuid1())

        if cluster_type == ClusterProcessType.TRAIN:
            cluster_name = "train-" + str(uuid.uuid1())

        if cluster_type == ClusterProcessType.PROFILE:
            cluster_name = "profile-" + str(uuid.uuid1())

        return cluster_name[:16]

    @staticmethod
    def get_training_compute(workspace,
                             cluster_name: str = None,
                             vm_size: str =
                             MLOComputeConstants.DEFAUlT_VM_SIZE_TRAINING,
                             min_nodes: int =
                             MLOComputeConstants.DEFAULT_MIN_NODES_TRAINING,
                             max_nodes: int =
                             MLOComputeConstants.DEFAULT_MAX_NODES_TRAINING,
                             compute_cluster_type: str = MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CLUSTER
                             ):
        """Obtain a cluster for training execution.

        Create or tries to recover existing compute cluster.
        if cluster_name is provided, then existing cluster
        with the same name is returned. If not, a new cluster
        is created. This method is used for single and multi
        /hyperparameter training.

        This function is intended to add minimal parameters,
        adding default parameters when required.

        workspace (Workspace): AzureML workspace name
        vm_size (str, optional): [description]. Defaults to
              MLOComputeConstants.DEFAULT_VM_SIZE.
        min_nodes (int, optional): Min number of nodes. Defaults to 0.
        max_nodes (int, optional): Max number of nodes. Defaults to 1.
        compute_cluster_type(str): Type of compute. Use Compute Cluster o use
                Compute Instance. For Compute Cluster Use MLOComputeConstants.
                COMPUTE_CLUSTER_TYPE_CLUSTER. For Computer Instance, use 
                MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CI
        """

        if compute_cluster_type == MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CLUSTER: 
            cluster = None
            if cluster_name is not None:
                # Try to get existing cluster
                cluster = ComputeTarget(workspace, cluster_name)
                #cluster = AmlCompute(workspace, cluster_name)
            else:

                # Generate a new cluster name
                cluster_name = MLOCompute.generateClusterProcessName(
                    ClusterProcessType.TRAIN)

                # Create compute cluster
                print("Creando compute cluster para entrenamiento con nombre " + cluster_name )
                cluster = MLOCompute.get_compute(
                    workspace, cluster_name=cluster_name, vm_size=vm_size,
                    min_nodes=min_nodes, max_nodes=max_nodes)

                print("creado cluster ")
        else:
            try:
                # Create or find compute instance
                cluster = ComputeTarget(workspace,cluster_name)
                print("locating CI as ComputeTarget with name "+ cluster_name)
            except Exception as compute_not_found:
                print("Checking if CI exists. It does not exists. Showing detailed exception response")
                print("".join(traceback.TracebackException.from_exception(compute_not_found).format()))
                print("Error, cannot find instance with name " + cluster_name)

        return cluster

    @staticmethod
    def get_profile_compute(workspace, vm_size: str =
                            MLOComputeConstants.DEFAULT_VM_SIZE,
                            min_nodes: int = 0,
                            max_nodes: int = 1,
                            idle_seconds_before_scaledown: int =
                            MLOComputeConstants.
                            DEFAULT_IDLE_SECONDS_BEFORE_SCALE_DOWN):
        """Creates a compute cluster for executing a Data Profiling

        Args:
            workspace ([type]): [description]
            vm_size (str, optional): [description]. Defaults to
                MLOComputeConstants.DEFAULT_VM_SIZE.
            min_nodes (int, optional): [description]. Defaults to 0.
            max_nodes (int, optional): [description]. Defaults to 1.
            idle_seconds_before_scaledown (int, optional): Node idle time in
            seconds before scaling down the cluster when create a compute
            cluster. Defaults to
            MLOComputeConstants.DEFAULT_IDLE_SECONDS_BEFORE_SCALE_DOWN.

        Returns:
            AmlCompute: AML Compute resource created
        """
        cluster_name = MLOComputeConstants\
            .DEFAULT_COMPUTE_INSTANCE_PROFILE_NAME

        return MLOCompute.get_compute(workspace,
                                      cluster_name=cluster_name,
                                      vm_size=vm_size,
                                      min_nodes=min_nodes, max_nodes=max_nodes,
                                      idle_seconds_before_scaledown=idle_seconds_before_scaledown)

    @staticmethod
    def get_compute(workspace, cluster_name: str = None,
                    vm_size: str =
                    MLOComputeConstants.DEFAULT_VM_SIZE,
                    min_nodes: int = 0,
                    max_nodes: int = 1,
                    idle_seconds_before_scaledown: int =
                    MLOComputeConstants.
                    DEFAULT_IDLE_SECONDS_BEFORE_SCALE_DOWN,
                    admin_username: str =
                    MLOComputeConstants.DEFAULT_VM_ADMIN_USER,
                    admin_user_password: str =
                    "Testazureuser1-" + str(uuid.uuid1())
                    ):
        """Creates a compute cluster for generic use
        Args:
            workspace ([type]): [description]
            vm_size (str, optional): [description]. Defaults to
                MLOComputeConstants.DEFAULT_VM_SIZE.
            min_nodes (int, optional): [description]. Defaults to 0.
            max_nodes (int, optional): [description]. Defaults to 1.
            idle_seconds_before_scaledown (int, optional): Node idle time in
            seconds before scaling down the cluster when create a compute
            cluster. Defaults to
            MLOComputeConstants.DEFAULT_IDLE_SECONDS_BEFORE_SCALE_DOWN.

        Returns:
            AmlCompute: AML Compute resource created
        """

        if cluster_name is None or not cluster_name.strip:
            raise ValueError(
                "Error, clustername is invalid or is not provided")

        cluster_config = AmlCompute.provisioning_configuration(
            vm_size=vm_size,
            min_nodes=min_nodes,
            max_nodes=max_nodes,
            idle_seconds_before_scaledown=idle_seconds_before_scaledown,
            admin_username=admin_username,
            admin_user_password=admin_user_password,
            identity_type="SystemAssigned"
        )

        compute = AmlCompute.create(workspace, cluster_name, cluster_config)

        # Waiting for cluster creation
        compute.wait_for_completion(show_output=True)

        return compute
