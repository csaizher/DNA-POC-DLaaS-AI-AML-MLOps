import json


class MLOPipelineUtils():
    """Support funtions used during inference.
    """

    @staticmethod
    def load_prediction_columns(dataset_predictions_columns: str = None):
        """Read output prediction columns for the dataset registration.

            Parses prediction columns received as JSON input string. If None,
            no columns are returned (empty array).

            TODO: Currently, ADF requires to add extra quotes to not collide with
            JSON quotes. These are removed. Check this issue to remove this 
            consideration. This only happens when the AzureML pipeline is invoked
            directly from ADF and not from AzureML. Also, input string is trimmed
            (initial and end whitespaces are removed). So, next examples are valids:

            '{ "columns": ["prediction_column1"] }'
            '\'{ "columns": ["prediction_column1"] }'
            '\'{ "columns": ["prediction_column1"] }\''
            '{ "columns": ["prediction_column1"] }\''
            '\' { "columns": ["prediction_column1"] } \''

        Args:
            dataset_predictions_columns_json (str, optional): JSON string containing column information. Defaults to None.

        Returns:
             dataset_predictions_columns_array (array): Array containing column names for each element. 
                Defaults to empty dict.
        """

        dataset_predictions_columns_array = []

        if dataset_predictions_columns is not None:
            try:

                # TODO: To improve. JSON fired from ADF comes with extra quotes
                dataset_predictions_columns_json = dataset_predictions_columns.strip()

                if dataset_predictions_columns_json.startswith("'") or dataset_predictions_columns_json.endswith("'"):

                    # Remove left quote
                    if dataset_predictions_columns_json.startswith("'"):
                        dataset_predictions_columns_json = dataset_predictions_columns_json[1:len(
                            dataset_predictions_columns_json)].strip()

                    # Remove right quote
                    if dataset_predictions_columns_json.endswith("'"):
                        dataset_predictions_columns_json = dataset_predictions_columns_json[0:len(
                            dataset_predictions_columns_json)-1].strip()

                dataset_predictions_columns_array = json.loads(
                    dataset_predictions_columns_json)['columns']

            except json.decoder.JSONDecodeError as json_error:
                # logger.warning(
                trace_id = 'N/A'
                print(
                    f"{trace_id}|mlopipelineutils|do_pipline_step()|Error while loading inference dataset header columns. Invalid JSON containing output columns. Setting parameters to empty value|Inference columns string recevied : [{dataset_predictions_columns}]")
                #raise json_error
            except KeyError as key_error:
                trace_id = 'N/A'
                print(
                    f"{trace_id}|mlopipelineutils|do_pipeline_step()|Error while loading inference dataset header columns. JSON parsed but no column field/keyfound. Setting parameters to empty value|Inference columns string recevied : [{dataset_predictions_columns}]. Inference columns string parsed: [{dataset_predictions_columns_json}]")
                #raise key_error

            return dataset_predictions_columns_array
