import argparse
import os

from azureml.core import Datastore
from azureml.core import Run
import pandas as pd
import tempfile
import shutil

from .mlopipelineutils import MLOPipelineUtils


class MLOSaveStepInference:

    """Contains execution code for the Save Step during Batch Inference.

    """
    @staticmethod
    def do_save_step():
        """ Execute the code required on the save step for deploying an inference batch pipeline.
            The output file will be replace with the current one
        """
        parser = argparse.ArgumentParser("save")

        parser.add_argument("-dpifn", "--dataset-predictions-input-filename", type=str,
                            help="Source predictions filename", required=True, dest='dataset_predictions_input_filename')
        parser.add_argument("-dpifp", "--dataset-predictions-input-filepath", type=str,
                            help="Source predictions filepath", required=True, dest='dataset_predictions_input_filepath')
        parser.add_argument("-dpc", "--dataset-predictions-columns", type=str,
                            help="Header columns for the registered dataset", required=True, dest='dataset_predictions_columns')
        parser.add_argument("-od", "--output-datastore", type=str,
                            help="Output Datastore to upload the input file", required=True, dest='output_datastore')
        parser.add_argument("-of", "--output-filepath", type=str,
                            help="Output Filepath to upload the input file", required=True, dest='output_filepath')

        args = parser.parse_args()

        input_filename = args.dataset_predictions_input_filename
        input_filepath = args.dataset_predictions_input_filepath
        output_datastore = args.output_datastore
        output_filepath = args.output_filepath

        # Read output prediction columns for the dataset registration
        dataset_predictions_columns = MLOPipelineUtils.load_prediction_columns(
            args.dataset_predictions_columns)

        # Get AzureML resources to access to Datastore
        workspace = Run.get_context().experiment.workspace
        datastore = Datastore.get(workspace, output_datastore)

        # Figure out the final input file
        input_file = os.path.join(input_filepath, input_filename)

        # Load as Panda Dataframe the predictions
        df_predictions = pd.read_csv(
            input_file, sep=" ", header=None, names=dataset_predictions_columns)

        # Save to local to upload to Datastore

        # Create temporal folder for intermediate files
        tmp_dataset_path = tempfile.mkdtemp(prefix="mlops-ds-tmp-")

        try:
            df_predictions_file = os.path.join(
                tmp_dataset_path, input_filename)
            df_predictions.to_csv(df_predictions_file, index=False)

            # Save/copy input file to output file
            datastore.upload_files(files=[
                                   df_predictions_file], target_path=output_filepath, overwrite=True, show_progress=True)

            # Delete temporary files
            shutil.rmtree(tmp_dataset_path)

        except:

            # Delete temporary files
            shutil.rmtree(tmp_dataset_path)
            raise RuntimeError(
                'Error uploading predictions to external Datastore ['+output_datastore+'] with filepath [' + output_filepath + ']')
