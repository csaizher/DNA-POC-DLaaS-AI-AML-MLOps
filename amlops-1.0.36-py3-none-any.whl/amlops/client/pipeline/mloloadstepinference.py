import argparse

from azureml.core import Datastore
from azureml.core import Dataset
from azureml.core import Run


class MLOLoadStepInference:

    """Class containing execution code for the Load Step during Batch Inference.

    """
    @staticmethod
    def do_load_step():
        """Pipeline code for the load step

        Execute the code required on the register step for deploying an
        inference batch pipeline.
        """
        parser = argparse.ArgumentParser("register")
        parser.add_argument("--input-filepath", type=str, help="Input file",
                            dest='input_filepath')
        parser.add_argument("--input-datastore", type=str,
                            help="Input datastore", dest='input_datastore')
        parser.add_argument("--output-filedataset", type=str,
                            help="Output folder where to place the input file",
                            required=True, dest='output_filedataset')

        args = parser.parse_args()

        input_datastore = args.input_datastore
        input_filepath = args.input_filepath
        output_filedataset = args.output_filedataset

        workspace = Run.get_context().experiment.workspace
        datastore = Datastore.get(workspace, input_datastore)

        # Create a FileDataset from current file location
        data_dataset_file = Dataset.File.from_files(
            path=(datastore, input_filepath))

        # Copy FileDataset to internal output folder
        data_dataset_file.download(target_path=output_filedataset,
                                   overwrite=True)
