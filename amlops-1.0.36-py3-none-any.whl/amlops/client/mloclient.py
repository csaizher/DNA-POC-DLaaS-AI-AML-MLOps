from ..configuration.mlohyperparameters_config_types\
    import MLOHypermetersConfigTypes


class MLOClient():
    """Support funtions used for the other modules.
    """

    @staticmethod
    def update_args_hyperparameter_types(dynamic_args: dict = None):
        """Update hyperparameter data types according input key-value list

            From the input list arguments extract which arguments are related
            to hyperparameters config types and apply the correct data type
            for each hyperparameter. The returned list is filtered, removing
            hyperparameter data-type information.

            Example:

            Input dictionary (all values are strings):

                dynamic_args = {
                    n_jobs: '20',
                    n_jobs-type: 'int',
                    n_estimators: '1',
                    n_estimators-type: 'int',
                    min_samples_leaf: '3',
                    min_samples_leaf-type: 'int',
                    alpha: '0.2',
                    alpha-type: 'float'
                }

            Output dictionary (data type keys, "*-type" are removed and
            the datatypes are updated from string to correct type):

                dynamic_args_filtered = {
                    n_jobs: 20,  # (updated to integer type)
                    n_estimators: 1, # (updated to integer type)
                    min_samples_leaf: 3, # (updated to integer type)
                    alpha: '0.2', # (updated to float type)
                }

        Args:
            dynamic_args (dict, optional): [description]. Defaults to None.
        """

        dynamic_args_filtered = {}
        hyperparameters_config_types = {}
        hyperparameters_sufix = "-type"
        hyperparameters_sufix_len = len(hyperparameters_sufix)
        for argument in dynamic_args:
            # Check if the argument is an hyperparameter data-configuration
            if argument.endswith("-type"):
                hyperparameters_name = argument[:-(hyperparameters_sufix_len)]
                hyperparameters_config_types[hyperparameters_name] = dynamic_args[argument]
            else:
                dynamic_args_filtered[argument] = dynamic_args[argument]

        # Convert to correct type
        for argument in dynamic_args_filtered:
            if argument in hyperparameters_config_types:
                dynamic_args_filtered[argument] = MLOHypermetersConfigTypes.convert(hyperparameters_config_types[argument],
                                                                                    dynamic_args_filtered[argument])

        return dynamic_args_filtered

    @staticmethod
    def args_to_dict(dynamic_args: dict = None):
        """Convert unknown arguments from argparse to a dictionary object

        Convert unknown arguments from argparse to a dictionary object

        Args:
            dynamic_args (dict, optional): Dictionary with argparse parsed format. Defaults to None.

         Returns:
            dynamic_args_dict: dictionary with a list of parameters in the form key=value

        """
        # Hyperparameter dict
        dynamic_args_dict = {}
        # Behaviour:    if some argument starts with "-" or "--" it is an potential valid argument
        #               if potential valid argument contains "=", it is a valid argument with "key" the left side of "=" and "value" the right side. If "value" is empty, "None" is assigned as "value"
        #               if potential valid argument does not contain "=", right side of "--" is the key and the "value" the next parameter, or "None" if no next parameter exists
        key = ""
        value = ""
        key_found = False
        for arg in dynamic_args:
            if arg.startswith("--"):
                if arg.find("=") != -1:
                    result = arg.split("=")
                    key = result[0][2:]
                    value = result[1]
                    dynamic_args_dict[key] = value
                    key_found = False
                else:
                    if not key_found:
                        key = arg
                        key = key[2:]
                        key_found = True
                    else:
                        value = arg
                        dynamic_args_dict[key] = value
                        key_found = False
            elif arg.startswith("-"):
                if arg.find("=") != -1:
                    result = arg.split("=")
                    key = result[0]
                    value = result[1]
                    dynamic_args_dict[key] = value
                    key_found = False
                else:
                    if not key_found:
                        key = arg
                        key = key[1:]
                        key_found = True
                    else:
                        value = arg
                        dynamic_args_dict[key] = value
                        key_found = False
            else:
                if key_found:
                    value = arg
                    dynamic_args_dict[key] = value
                    key_found = False

        return dynamic_args_dict
