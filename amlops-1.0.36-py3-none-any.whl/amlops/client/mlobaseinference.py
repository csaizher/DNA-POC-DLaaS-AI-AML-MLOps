from azureml.core.model import Model

import argparse


import joblib
import json

# Used for logging and performance
from azureml_user.parallel_run import EntryScript
import time
import uuid


class BaseInference:

    """Base MLOps Inference class.

    This is a helper class for the execution of inferences. This class
    autoloads the model with the right version received as parameters.
    To create a subclass, you must implement the following two methods:

    1) def init(self, run, model): Implement some initialization before
    running the inference. This method is only called one time. You
    receive the "Run" AzureML object in case you need for some specific
    operation.


    2) def run(self, batch_dataset, model): Implement the inference itself.
    Input data is received as parameter. Also, the model, loaded preiously
    is passed as parameter.

    """

    run_aml = None
    model = None
    trace_id = None
    extra_params = {}

    def __init__(self, run):
        self.run_aml = run
        self.model = None
        self.trace_id = str(uuid.uuid1())

    def __load_model(self, model_name: str, model_version: str = None):

        if model_version is None:
            model_path = Model.get_model_path(
                model_name=model_name, _workspace=self.run_aml.experiment.workspace)
        else:
            model_version = int(model_version)
            model_path = Model.get_model_path(
                model_name=model_name, version=model_version, _workspace=self.run_aml.experiment.workspace)

        # Load model
        self.model = joblib.load(model_path)

    def do_init(self):
        """Do MLOPs inference initialization stuff.

        MLOPs proteceted method. Users should not extend or override their
        functionality. It does initializations required by MLOPs. Actions
        permormed are:
            - Parsing of input parameters from AML and the MLOPs framework
            - Model loading accourding the model name and the model version
            - Call to init() user function for subclasses implementations

        Args:
            None
        Returns:
            None
        """
        entry_script = EntryScript()
        logger = entry_script.logger
        tinit = time.perf_counter()
        # Retrieve model from name and version, as input arguments
        inference_model_parser = argparse.ArgumentParser(
            description="Inference using simple model")
        inference_model_parser.add_argument(
            "-m", "--model-name", help="Registration name of the model", required=True)
        inference_model_parser.add_argument(
            "-mv", "--model-version", help="Version of the registered model", required=False)
        inference_model_parser.add_argument(
            "-mip", "--model-inference-parameters", help="Version of the registrated model", required=False)

        args, _ = inference_model_parser.parse_known_args()

        # Update extra parameters
        if args.model_inference_parameters is not None:
            try:
                # TODO: To improve. JSON fired from ADF comes with extra quotes
                extra_params_json = "{}"
                if args.model_inference_parameters[0:1] == "'":
                    extra_params_json = args.model_inference_parameters[1:len(
                        args.model_inference_parameters)]

                if args.model_inference_parameters[len(args.model_inference_parameters)-1:len(args.model_inference_parameters)] == "'":
                    extra_params_json = extra_params_json[0:len(
                        extra_params_json)-1]

                self.extra_params = json.loads(extra_params_json)

            except json.decoder.JSONDecodeError as json_error:
                logger.warning(
                    f"{self.trace_id}|scoring|do_init()|Error while loading model inference parameters. Set parameters to empty value|Inference parameter string recevied : [{args.model_inference_parameters}]")

        # Load model
        tinit_load_model = time.perf_counter()
        self.__load_model(args.model_name, args.model_version)
        tend_load_model = time.perf_counter()
        logger.info(
            f"{self.trace_id}|scoring|load_model()|{tend_load_model - tinit_load_model:0.4f} seconds|N/A")

        # Call subclasses initialization code
        tinit_init = time.perf_counter()
        self.init(self.run_aml, self.model)
        tend_init = time.perf_counter()
        logger.info(
            f"{self.trace_id}|scoring|init()|{tend_init - tinit_init:0.4f} seconds|N/A")

        tend = time.perf_counter()
        logger.info(
            f"{self.trace_id}|scoring|do_init()|{tend - tinit:0.4f} seconds|N/A")

    def do_run(self, batch_dataset):
        """Do MLOPs pre inference tasks.

        MLOPs proteceted method. Users should not extend or override their functionality. 
        It does any task to prepare the inference execution. This includes:
            - Recover model loaded from "init" step
            - Call the run() user function for subclasses implementation passing the model

        Args:
            batch_dataset (Dataframe): Pandas daframe to evaluate or do the inference against the model

        Returns:
            None
        """
        entry_script = EntryScript()
        logger = entry_script.logger
        tinit = time.perf_counter()
        try:
            logger.info(
                f"{self.trace_id}|scoring|do_run()|N/A|{batch_dataset.shape[0]} rows")
        except:
            logger.info("Cannot trace number of rows (Class) " +
                        str(type(batch_dataset)))
            logger.info("Cannot trace number of rows (Content)" +
                        str(batch_dataset))
            dir(batch_dataset)

        # Call subclasses inference code
        tinit_run = time.perf_counter()
        result = self.run(self.model, batch_dataset, self.extra_params)
        tend_run = time.perf_counter()

        try:
            logger.info(
                f"{self.trace_id}|scoring|run()|{tend_run - tinit_run:0.4f} seconds|{batch_dataset.shape[0]} rows")
        except:
            logger.info("Cannot 2 trace number of rows (Class) " +
                        str(type(batch_dataset)))
            logger.info(
                "Cannot 2 trace number of rows (Content)" + str(batch_dataset))
            dir(batch_dataset)

        tend = time.perf_counter()

        try:
            logger.info(
                f"{self.trace_id}|scoring|do_run()|{tend - tinit:0.4f} seconds|{batch_dataset.shape[0]} rows")
        except:
            logger.info("Cannot 3 trace number of rows (Class) " +
                        str(type(batch_dataset)))
            logger.info(
                "Cannot 3 trace number of rows (Content)" + str(batch_dataset))
            dir(batch_dataset)

        return result

    def init(self, run, model):
        """Do subclass inference initialization.

        Users should override this funtcion with the inference initialization code. 
        The user can add initialization code before running the inference.
        This method is only called one time. You receive the "Run" AzureML object in case you
        need for some specific operation.

        Args:
            run: AzureML object in case you need to access from execution property
            model: Loaded model configured for the execution

        Returns:
            None
        """
        entry_script = EntryScript()
        logger = entry_script.logger
        logger.info(
            "TODO: this method should be implemented. Inference initizalization code for parallel inference goes here.")

    def run(self, model, batch_dataset, extra_params: dict = {}):
        """Do inference execution.

        Users should override this funtcion with the inference execution code.
        Add the implementation of the inference process. Input data is received
        as parameter. Also, the model, loaded preiously is passed as parameter.

        Args:
            model: Loaded model configured for the execution
            batch_dataset (Dataframe): Dataframe whith content is the input for
                the inference
            extra_params (dict): Extra parameters required by the inference

        Returns:
            None
        """
        entry_script = EntryScript()
        logger = entry_script.logger
        logger.info(
            "TODO: this method should be implemented. Inference code for parallel inference goes here.")
