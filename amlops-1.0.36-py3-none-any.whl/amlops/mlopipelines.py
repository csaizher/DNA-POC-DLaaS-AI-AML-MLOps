# Support for MLOPs pipelines for Inference
from .mloutils import MLOUtils
from .mlocore import MLOCore
from .client.pipeline.mloregisterstepinference_parameters \
 import MLORegisterStepInferenceParameters
from .configuration.mloinferenceconfiguration \
 import MLOInferenceConfiguration

# This is only to show the progress when you are on notebooks
# from azureml.widgets import RunDetails
from azureml.pipeline.steps import ParallelRunStep, ParallelRunConfig
from azureml.data import OutputFileDatasetConfig
from azureml.data.dataset_consumption_config import DatasetConsumptionConfig

from azureml.pipeline.core import PipelineParameter
from azureml.pipeline.steps import PythonScriptStep
from azureml.core import RunConfiguration
from azureml.pipeline.core import OutputPortBinding, InputPortBinding

import os


class MLOPipelines:

    @staticmethod
    def create_load_output(inference_dataset_datatypes):

        # NOT USED at this moment
        # dataset_registration_name = "daas-lab-frc-dataset-inference-ai-001-use-case"

        # Convert to Tabular dataset
        # If not, a FileDataset is returned
        # In case of FileDataset, partition is done by file and the input is a MiniBatch (a path with the file to be processed)
        # In case of TabularDataset, a df is returned as batches. In case of TabularDataset conversion, all fields are threated as string, so a explicit conversion is required
        #   Conversion, see: https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.data.output_dataset_config.transformationmixin?view=azure-ml-py#read-delimited-files-include-path-false--separator------header--promoteheadersbehavior-all-files-have-same-headers--3---partition-format-none--path-glob-none--set-column-types-none-

        # Decode columntypes from JSON STRING to DICT
        inference_dataset_datatypes_dict = MLOInferenceConfiguration.inference_dataset_datatypes_from_str(inference_dataset_datatypes)
        load_output_filedataset = OutputFileDatasetConfig(name='load_output').read_delimited_files(
            set_column_types=inference_dataset_datatypes_dict)
        # Dataset Registration not performed at this version. Use ".register_on_complete(dataset_registration_name)" to add it

        return load_output_filedataset

    @staticmethod
    def create_execute_step(workspace, compute_target, environment_name,
                            pp_batch_size, pp_node_count,
                            pp_process_count_per_node,
                            pp_run_invocation_timeout,
                            load_inference_step_output,
                            pp_model_name, pp_model_inference_parameters,
                            pp_model_version,
                            dockerfile, docker_source):

        # Fixed configuration
        entry_script = "score.py"

        # Create/update Inference environment from MLOPs
        environment = MLOCore.create_or_update_environment(workspace,
                                                           environment_name,
                                                           dockerfile,
                                                           docker_args=None)

        execute_output_filename = 'execute_output.csv'
        parallel_run_config = ParallelRunConfig(
            entry_script=entry_script,
            mini_batch_size=pp_batch_size,
            error_threshold=1,
            output_action='append_row',
            append_row_file_name=execute_output_filename,
            environment=environment,
            compute_target=compute_target,
            node_count=pp_node_count,
            process_count_per_node=pp_process_count_per_node,
            run_invocation_timeout=pp_run_invocation_timeout,
            source_directory=docker_source)

        # Create input for this step from the register input dataset
        execute_inference_step_input = DatasetConsumptionConfig(name="execute_input", dataset=load_inference_step_output, mode='direct')

        # Create output for this step (see: https://docs.microsoft.com/en-us/python/api/azureml-core/azureml.data.output_dataset_config.outputfiledatasetconfig?view=azure-ml-py)
        execute_inference_step_output = OutputPortBinding("execute_output", datastore=workspace.get_default_datastore())

        # Create step
        execute_inference_step = ParallelRunStep(
            # Step name: [-,a-z,0-9] maximum lenght = 32 chars
            name='vr-execute-s00',
            inputs=[execute_inference_step_input],
            output=execute_inference_step_output,
            parallel_run_config=parallel_run_config,
            arguments=['--model-name', pp_model_name, '--model-inference-parameters', pp_model_inference_parameters, "--model-version", pp_model_version],
            allow_reuse=False)

        return execute_inference_step, execute_inference_step_output, execute_output_filename

    @staticmethod
    def create_register_step(workspace, compute_target, environment_name,
                             execute_inference_step_output,
                             execute_output_filename,
                             load_inference_step_output,
                             pp_output_inference_columns,
                             docker_source):

        """Register input (prediction requests) dataset and output (predictions) dataset.
        """
        register_input_requests_name = "register_input_requests"
        register_inference_step_input_predictions = InputPortBinding("register_input_predictions", bind_object=execute_inference_step_output)
        register_inference_step_input_requests = DatasetConsumptionConfig(name=register_input_requests_name, dataset=load_inference_step_output, mode='direct')

        register_source = docker_source
        register_environment_name = "mlops-register-step-inference"
        register_docker_image = os.path.join(register_source,'Dockerfile')
        dockerfile = register_docker_image
        environment_name = register_environment_name
        register_environment = MLOCore.create_or_update_environment(workspace, environment_name, dockerfile, docker_args=None)
        register_run_config = RunConfiguration()
        register_run_config.environment = register_environment

        register_inference_step_arguments = []

        # Common datastore registration
        register_inference_step_arguments.extend(["--datastore",
                                                 "aml_application_data"])

        dataset_request_name_param = PipelineParameter(
            name=MLORegisterStepInferenceParameters
            .DATASET_REQUEST_NAME.value.name(),
            default_value=MLORegisterStepInferenceParameters
            .DATASET_REQUEST_NAME.value.default_value())

        dataset_request_desc_param = PipelineParameter(
            name=MLORegisterStepInferenceParameters
            .DATASET_REQUEST_DESC.value.name(),
            default_value=MLORegisterStepInferenceParameters
            .DATASET_REQUEST_DESC.value.default_value())

        dataset_predictions_name_param = PipelineParameter(
            name=MLORegisterStepInferenceParameters
            .DATASET_PREDICTIONS_NAME.value.name(),
            default_value=MLORegisterStepInferenceParameters
            .DATASET_PREDICTIONS_NAME.value.default_value())

        dataset_predictions_desc_param = PipelineParameter(
            name=MLORegisterStepInferenceParameters
            .DATASET_PREDICTIONS_DESC.value.name(),
            default_value=MLORegisterStepInferenceParameters
            .DATASET_PREDICTIONS_DESC.value.default_value())

        # Dataset registration metadata configure as parameter
        register_inference_step_arguments.extend(["--dataset-requests-name",
                                                 dataset_request_name_param])
        register_inference_step_arguments.extend(["--dataset-requests-desc",
                                                 dataset_request_desc_param])
        register_inference_step_arguments.extend(["--dataset-predictions-name",
                                                 dataset_predictions_name_param
                                                  ])
        register_inference_step_arguments.extend(["--dataset-predictions-desc",
                                                 dataset_predictions_desc_param
                                                  ])

        # Input inference predictions file received as InputPortBinding from execution step
        register_inference_step_arguments.extend(["--dataset-predictions-input-filename", execute_output_filename])
        register_inference_step_arguments.extend(["--dataset-predictions-input-filepath", register_inference_step_input_predictions])
        # Input inference requests file received as DataconsumptionConfig dataset from load step
        register_inference_step_arguments.extend(["--dataset-requests-input-filename", register_inference_step_input_requests])
        # Input name to recover later
        register_inference_step_arguments.extend(["--dataset-predictions-input-name", register_input_requests_name])
        register_inference_step_arguments.extend(["--dataset-predictions-columns", pp_output_inference_columns])
        register_inference_step = PythonScriptStep(
                # Step name: [-,a-z,0-9] maximum lenght = 32 chars
                name="vr-register-s00",
                script_name="./register.py",
                compute_target=compute_target,
                source_directory=register_source,
                arguments=register_inference_step_arguments,
                runconfig=register_run_config,
                inputs=[register_inference_step_input_requests, register_inference_step_input_predictions],
                outputs=[],
                allow_reuse=False)

        return register_inference_step

    @staticmethod
    def create_load_step(workspace, compute_target, environment_name,
                         pp_input_datastore, pp_input_filepath,
                         dockerfile, docker_source,
                         inference_dataset_datatypes):

        """Load input data as dataset for next steps.

        Next steps requires a dataset. This steps load the file as dataset and
        if propagates the dataset as input argument for the next step.

        Args:
            workspace (Workspace): AzureML workspace who has the resources to
                build and publish the pipeline
            compute_target (str): AzureML compute target name for the execution of this step
            environment_name (str): AzureML environment name containing docker configuration
            execute_inference_step_output (OutputPortBinding): Output received as a mounted
                directory during local docker execution. It is the folder which prediction files
                has been generated by the previous scoring/execution step.
            execute_output_filename (str): Name of the generated file from previous step which
                contains the predictions.
            pp_input_datastore (PipelineParameter): Pipeline parameter containing the name of
                the datastore to load for prediction requests file.
            pp_input_filepath (PipelineParameter): Pipeline parameter containing the source
                path to load the prediction requests file.
            output_dataset: Name of the output dataset
            dockerfile (str): Name of the dockerfile file
            docker_source (str): Path containing the root path for the docker environment containing
                code and other resources to be deployed into docker image.
            inference_dataset_datatypes: the datatypes for the loaded dataset

        Returns:
            load_inference_step: the load step of the inference pipeline
            load_inference_step_output: the output to be used for next steps

        """
        load_input_datastore = pp_input_datastore
        load_input_filepath = pp_input_filepath

        # Create output for this step
        load_inference_step_output = \
            MLOPipelines.create_load_output(inference_dataset_datatypes)

        # Create environent
        load_environment = \
            MLOCore.create_or_update_environment(workspace,
                                                 environment_name,
                                                 dockerfile, docker_args=None)
        load_run_config = RunConfiguration()
        load_run_config.environment = load_environment

        load_inference_step = PythonScriptStep(
                # Step name: [-,a-z,0-9] maximum lenght = 32 chars
                name="vr-load-s00",
                script_name="./load.py",
                compute_target=compute_target,
                source_directory=docker_source,
                arguments=['--input-datastore', load_input_datastore, '--input-filepath', load_input_filepath, '--output-filedataset', load_inference_step_output],
                runconfig=load_run_config,
                inputs=[],
                outputs=[load_inference_step_output],
                allow_reuse=False)

        return load_inference_step, load_inference_step_output

    @staticmethod
    def create_save_step(workspace, compute_target, environment_name,
                         execute_inference_step_output,
                         execute_output_filename,
                         pp_output_datastore, pp_output_filepath,
                         pp_output_inference_columns, docker_source):

        """ Save the predictions in the output folder specified in the pipeline

        Last step for inference pipeline. It saves the prediction on the output
        datastore with the path and filename specified as parameter.

        Args:
            workspace (Workspace): AzureML workspace who has the resources to build
                and publish the pipeline
            compute_target (str): AzureML compute target name for the execution of this step
            environment_name (str): AzureML environment name containing docker configuration
            execute_inference_step_output (OutputPortBinding): Output received as a mounted
                directory during local docker execution. It is the folder which prediction files
                has been generated by the previous scoring/execution step.
            execute_output_filename (str): Name of the generated file from previous step which
                contains the predictions.
            pp_output_datastore (PipelineParameter): Pipeline parameter containing the name of
                the datastore to save prediction file.
            pp_output_filepath (PipelineParameter): Pipeline parameter containing the destination
                path for the predicion file.
            docker_source (str): Path containing the root path for the docker environment containing
                code and other resources to be deployed into docker image.

        Returns:
            save_inference_step: the save step of the inference pipeline

        """

        save_inference_step_input_predictions = \
            InputPortBinding("save_input",
                             bind_object=execute_inference_step_output)
        save_environment_name = "mlops-save-step-inference"
        save_docker_image = os.path.join(docker_source, 'Dockerfile')
        dockerfile = save_docker_image
        environment_name = save_environment_name
        save_environment = \
            MLOCore.create_or_update_environment(workspace,
                                                 environment_name,
                                                 dockerfile, docker_args=None)
        save_run_config = RunConfiguration()
        save_run_config.environment = save_environment

        save_inference_step_arguments = []
        # Input inference predictions file received as InputPortBinding from execution step
        save_inference_step_arguments.extend(["--dataset-predictions-input-filename", execute_output_filename])
        save_inference_step_arguments.extend(["--dataset-predictions-input-filepath", save_inference_step_input_predictions])
        # Outputs for the data plataform
        save_inference_step_arguments.extend(['--output-datastore', pp_output_datastore])
        save_inference_step_arguments.extend(['--output-filepath', pp_output_filepath])

        save_inference_step_arguments.extend(["--dataset-predictions-columns", pp_output_inference_columns])

        save_inference_step = PythonScriptStep(
                # Step name: [-,a-z,0-9] maximum lenght = 32 chars
                name="vr-save-s00",
                script_name="./save.py",
                compute_target=compute_target,
                source_directory=docker_source,
                arguments=save_inference_step_arguments,
                runconfig=save_run_config,
                inputs=[save_inference_step_input_predictions],
                outputs=[],
                allow_reuse=False)

        return save_inference_step
