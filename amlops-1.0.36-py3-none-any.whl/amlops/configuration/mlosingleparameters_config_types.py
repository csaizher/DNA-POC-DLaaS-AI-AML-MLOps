from enum import Enum


class MLOSingleParametersConfigTypes(Enum):
    """Possible data types for single training parameters
    configuration.

    Values:
        STRING ([str]): Config type to represent a parameter which value type
            is a string.
        INTEGER ([str]): Config type to represent a parameter which value type
            is an integer.
        FLOAT ([str]):  Config type to represent a parameter which value type
            is a float.
        INVALID ([str]): Not valid data type.
    """
    INVALID = 0
    STRING = 1
    INTEGER = 2
    FLOAT = 3

    @staticmethod
    def get(data: object):
        """Return associated MLOSingleParametersConfigTypes input type.

        Checks valid types for MLOSingleParametersConfigTypes and return the
        associated MLOSingleParametersConfigTypes.

        Args:
            data (object): Object which type is tanking into an account to
                    return associated MLOSingleParametersConfigTypes

        Returns:
            MLOSingleParametersConfigTypes: The MLOSingleParametersConfigTypes
                associated to input data or
                MLOSingleParametersConfigTypes.INVALID if no valid type.
        """
        if isinstance(data, str):
            return MLOSingleParametersConfigTypes.STRING
        elif isinstance(data, int):
            return MLOSingleParametersConfigTypes.INTEGER
        elif isinstance(data, float):
            return MLOSingleParametersConfigTypes.FLOAT
        else:
            return MLOSingleParametersConfigTypes.INVALID

    @staticmethod
    def convert(type: str, data: str):
        """Convert input string to valid data type

        Convert input string to valid data type according
        parameter config type.

        Args:
            data (str): Input data to be converted from string
                to right datatype according "type" parameter
            type (str): Parameter config type name. It can have
                MLOSingleParametersConfigTypes.X.name values.
                Example:
                    MLOSingleParametersConfigTypes.STRING.name == STRING
        Returns:
            Data object converted to right data type. It data is 'None' or
            type is not valid, 'None' is returned

        """
        if data is None:
            return None

        if type == MLOSingleParametersConfigTypes.INTEGER.name:
            return int(data)
        elif type == MLOSingleParametersConfigTypes.FLOAT.name:
            return float(data)
        elif type == MLOSingleParametersConfigTypes.STRING.name:
            return data
        else:
            return None
