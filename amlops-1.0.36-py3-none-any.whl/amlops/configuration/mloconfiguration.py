from ruamel.yaml import YAML
from pathlib import Path


class MLOConfiguration():
    """Common methods for configuration files parsing.

        Common methods for the parsing of training and
        inference configuration files.
    """

    @staticmethod
    def model_params_from_yaml(configuration: str = None,
                               model_name: str = None,
                               model_description: str = None):
        """Return model configuration parameters for DevOps/MLOps scripts

            Return model configuration parameters and set default values if
            they are not present in the configuration and they are not passed
            as input values.

            Args:
                configuration (str, optional): File path containing training
                    configuration. Defaults to None.
                model_name (str, optional): Name of the model to be registered.
                    Defaults to None.
                model_description (str, optional): Description of the model.
                    Defaults to None.

            Returns:
                model_name (str, optional): Name of the model to be registered.
                    Defaults to None.
                model_description (str, optional): Description of the model.
                    Defaults to None.
            Raises:
                ValueError: training/inference configuration file path is not
                    provided
        """

        if configuration is None or not configuration.strip:
            raise ValueError(
                "Error, file configuracion path is not provided")

        model_name = 'None'
        model_description = 'None'
        model_version = 'None'

        # Load model and dataset data from YAML config file
        path = Path(configuration)
        yaml = YAML(typ='safe')
        config = yaml.load(path)
        if 'model' in config:
            if 'name' in config['model']:
                model_name = config['model']['name']
            if 'description' in config['model']:
                model_description = config['model']['description']
            if 'version' in config['model']:
                model_version = config['model']['version']

        return model_name, model_description, model_version
