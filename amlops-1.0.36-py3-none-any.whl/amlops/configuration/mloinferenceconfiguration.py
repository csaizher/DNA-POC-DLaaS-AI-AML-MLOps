from ruamel.yaml import YAML
from pathlib import Path

from azureml.data.dataset_factory import DataType
import json


class MLOInferenceConfiguration():
    """Common methods for configuration files parsing.
    """

    def inference_params_from_yaml(inference_configuration: str):
        """Return inference configuration parameters for DevOps/MLOps scripts

        Return inference configuration parameters. These parameters are default
        values for the deployment of the inference Pipeline.

        Args:
            configuration (str): File path containing training
                configuration. Defaults to None.

        Returns:

        Raises:
            ValueError: Inference configuration file path is not provided
        """

        if inference_configuration is None or \
                not inference_configuration.strip:
            raise ValueError(
                "Error, training configuracion path is not provided")

        if inference_configuration is not None:
            # Load model and dataset data from YAML config file
            path = Path(inference_configuration)
            yaml = YAML(typ='safe')
            config = yaml.load(path)

            batch_size = None
            process_count_per_node = None
            node_count = None
            run_invocation_timeout = None
            cluster_name = None
            model_inference_parameters = None
            environment_name = None
            inference_dataset_datatypes = {}
            pipeline_name = 'pipeline_usecase'
            pipeline_description = 'Pipeline usecase inference'

            if 'inference' in config:
                if 'inference_dataset_datatypes' in config['inference']:
                    inference_dataset_datatypes = config['inference']['inference_dataset_datatypes']
                if 'model_inference_parameters' in config['inference']:
                    environment_name = config['inference']['environment_name']
                if 'model_inference_parameters' in config['inference']:
                    model_inference_parameters = config['inference']['model_inference_parameters']
                if 'batch_size' in config['inference']:
                    batch_size = config['inference']['batch_size']
                if 'process_count_per_node' in config['inference']:
                    process_count_per_node = config['inference']['process_count_per_node']
                if 'node_count' in config['inference']:
                    node_count = config['inference']['node_count']
                if 'run_invocation_timeout' in config['inference']:
                    run_invocation_timeout = config['inference']['run_invocation_timeout']
                if 'cluster_name' in config['inference']:
                    cluster_name = config['inference']['cluster_name']
                if 'output_inference_columns' in config['inference']:
                    output_inference_columns = config['inference']['output_inference_columns']
                if 'pipeline_name' in config['inference']:
                    pipeline_name = config['inference']['pipeline_name']
                if 'pipeline_description' in config['inference']:
                    pipeline_description = config['inference']['pipeline_description']

        return model_inference_parameters, inference_dataset_datatypes, batch_size, process_count_per_node, node_count, run_invocation_timeout, cluster_name, environment_name, output_inference_columns, pipeline_name, pipeline_description

    @staticmethod
    def inference_dataset_datatypes_from_str(inference_dataset_datatypes_str: str = None):
        """Returns inference datatypes definition for the input inference file.

        Return a dict consisting a list of keys:values which keys are the name of the
        columnas, and the values, the datatype of these columns. Currently, only supports
        str, float and longs
        see: https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.data.output_dataset_config.transformationmixin?view=azure-ml-py#read-delimited-files-include-path-false--separator------header--promoteheadersbehavior-all-files-have-same-headers--3---partition-format-none--path-glob-none--set-column-types-none-

        Args:
            inference_dataset_datatypes_str (str): A json as a string. Each entry is a key:value pair represening the
                name of the column and the datatype.

        Returns:
            inference_dataset_datatypes (dict): A dict with the name of the column and their DataType according
            AzureML datatypes
            Currently datatime and stream are not supported, so they are ignored
            see: https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.data.output_dataset_config.transformationmixin?view=azure-ml-py#read-delimited-files-include-path-false--separator------header--promoteheadersbehavior-all-files-have-same-headers--3---partition-format-none--path-glob-none--set-column-types-none-
            see: https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.data.datatype?view=azure-ml-py
            see: datatime https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.data.datatype?view=azure-ml-py#to-datetime-formats-none-
            see: staream https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.data.datatype?view=azure-ml-py#to-stream-workspace--escaped-false-
        """

        inference_dataset_datatypes = {}

        try:
            inference_dataset_datatypes_json = json.loads(
                inference_dataset_datatypes_str)

            for column in inference_dataset_datatypes_json:
                if inference_dataset_datatypes_json[column] == "long".lower():
                    inference_dataset_datatypes[column] = DataType.to_long()
                if inference_dataset_datatypes_json[column] == "float".lower():
                    inference_dataset_datatypes[column] = DataType.to_float()
                if inference_dataset_datatypes_json[column] == "string".lower():
                    inference_dataset_datatypes[column] = DataType.to_string()
                if inference_dataset_datatypes_json[column] == "boolean".lower():
                    inference_dataset_datatypes[column] = DataType.to_bool()

        except json.decoder.JSONDecodeError as json_error:
            print(
                f"Cannot load column data types for inference. JSON format is invalid. Current content: [{inference_dataset_datatypes_str}]")

        return inference_dataset_datatypes
