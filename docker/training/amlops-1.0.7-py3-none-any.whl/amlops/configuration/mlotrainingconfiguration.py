from ruamel.yaml import YAML
from pathlib import Path

# @See https://github.com/Azure/MachineLearningNotebooks/blob/master/how-to-use-azureml/ml-frameworks/scikit-learn/train-hyperparameter-tune-deploy-with-sklearn/train-hyperparameter-tune-deploy-with-sklearn.ipynb
from azureml.train.hyperdrive.sampling import GridParameterSampling
from azureml.train.hyperdrive.run import PrimaryMetricGoal
from azureml.train.hyperdrive.parameter_expressions import choice

from amlops.configuration.mlohyperparameters_config_types import MLOHypermetersConfigTypes
from amlops.configuration.mlosingleparameters_config_types import \
    MLOSingleParametersConfigTypes
from amlops.mlocompute import MLOComputeConstants


from amlops.exceptions import MLOTrainingConfigurationException

# @See: https://docs.microsoft.com/en-us/python/api/azureml-train-core/azureml.train.hyperdrive.gridparametersampling?view=azure-ml-py
# @See: https://docs.microsoft.com/en-us/python/api/azureml-train-core/azureml.train.hyperdrive.hyperparametersampling?view=azure-ml-py
# param_sampling = GridParameterSampling( {
# "--hptest": choice('linear', 'rbf', 'poly', 'sigmoid')
# }
# )

from enum import Enum


class MLOTrainingType():
    """Training type.
    """

    def __init__(self, id: str):
        self.id = id

    def id(self):
        """Returns the id/name of the Training type

        Returns:
            Name of the Pipeline Parameter
        """
        return self.id


class MLOTrainingTypes(Enum):
    """Possible training types

    Values:
        SINGLE (str): Single training.
        HYPERPARAMETER (str): Multipl trainings using an hypersparameter
            search space.
        INVALID (str): Not valid training type.
    """
    INVALID = MLOTrainingType("invalid")
    SINGLE = MLOTrainingType("single")
    HYPERPARAMETER = MLOTrainingType("hyperparameter")

    def getId(id: str):
        """Return associated MLOTrainingType input type.

        Checks valid types for MLOTrainingTypes and return the
        associated MLOTrainingType.

        Args:
            id (str): String as the id of the training type

        Returns:
            MLOTrainingType: The MLOTrainingType
                associated to input id or
                MLOTrainingTypes.INVALID if no valid type.
        """
        if id is None or not isinstance(id, str):
            return MLOTrainingTypes.INVALID

        if id.lower() == MLOTrainingTypes.SINGLE.value.id:
            return MLOTrainingTypes.SINGLE

        if id.lower() == MLOTrainingTypes.HYPERPARAMETER.value.id:
            return MLOTrainingTypes.HYPERPARAMETER
        return MLOTrainingTypes.INVALID


class MLOTrainingConfiguration():
    """Support funtions used for training configuration.
    """

    @staticmethod
    def train_type_from_yaml(training_configuration: str = None):
        """Return train type from yaml configuration file.

        Returns the type of training to launch. If no valid type is
        provided an exception is raised. Training type could be whether
        single or hyperparameter (traning using hyperparameters).

        Example of YAML configuration:

            # Type of Trainning: single or hyperparameter (multiple trainings
            # using hyperparameters space)
            type: single

        @see MLOTrainingTypes

        Returns:
            type: the MLOTrainingTypes

        Raises:
            MLOTrainingConfigurationException: training type is invalid
        """
        if training_configuration is not None:
            # Load model and dataset data from YAML config file
            path = Path(training_configuration)
            yaml = YAML(typ='safe')
            train_config = yaml.load(path)

            if 'type' not in train_config['training']:
                raise MLOTrainingConfigurationException(
                    "Error, no training type provided")

            type = MLOTrainingTypes.getId(train_config['training']['type'])

            if type == MLOTrainingTypes.INVALID:
                raise MLOTrainingConfigurationException(
                    "Error, invalid training type")

            return type

    @staticmethod
    def execution_params_from_yaml(training_configuration: str = None):
        """Return train execution parameters from configuration file.

        Returns experiment execution parameters for the training.
        At the moment only show_output from the console when the
        training is launched. This option is not mandatory and default
        value is True

        Example of YAML configuration:

              # Show the output for the stdout when launching the experiment
              show_output: false

        @see https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.core.run(class)?view=azure-ml-py#azureml-core-run-wait-for-completion

        Returns:
            show_output: show_output value (bool)

        Raises:
            MLOTrainingConfigurationException: training show_output value is invalid
        """
        if training_configuration is not None:
            # Load model and dataset data from YAML config file
            path = Path(training_configuration)
            yaml = YAML(typ='safe')
            train_config = yaml.load(path)

            show_output = True

            if 'show_output' in train_config['training']:   
                show_output = train_config['training']['show_output']
                if type(show_output)!=bool:
                    raise MLOTrainingConfigurationException(
                        "Error, invalid value for show_output optional field. Current type " + type(show_output) + " with value " + show_output)

            return show_output

    @staticmethod
    def cluster_from_yaml(training_yaml: str, training: bool = False):
        """Load compute cluster name from YAML file.

        Parses YAML and it returns the cluster name. It
        distinguished between training or not training.
        If training is choosen, default compute cluster name
        from configuration is overriden if specific compute
        cluster name exists in the configuration.

        Args:
            training (bool): Optional prefix to indicate if compute is for
                training (True) or not (False)
            training_yaml (str): YAML file containing training configuration

            Example of specific YAML compute cluster configuration input:

                # Global compute configuration
                global:
                    # Default compute resource name
                    cluster_name: daas-vr-128-16-fmotosba
                # Training information
                training:
                    # Specific compute resource name for training
                    cluster_name: daas-cpvr-256-32
                    # Other training parameters....
        Returns:
            cluster_name: The name of the cluser
            compute_cluster_type: The type of compute, a cluster or a compute
                instance possible values: MLOComputeConstants.
                COMPUTE_CLUSTER_TYPE_CLUSTER ("cluster") for cluster or
                MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CI for Computer
                Instance ("ci")
        Raises:
            ValueError: training configuration file path is not provided
            MLOTrainingConfigurationException: In case no cluster name found
        """

        if training_yaml is None or not training_yaml.strip:
            raise ValueError(
                "Error, training configuracion path is not provided")

        path = Path(training_yaml)
        yaml = YAML(typ='safe')
        training_configuration = yaml.load(path)

        cluster_name = None

        # Default value
        compute_cluster_type = MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CLUSTER

        if training_configuration is None or len(training_configuration) == 0:
            return cluster_name

        # Recover cluster name from global parameters as default
        if 'global' in training_configuration:
            if 'cluster_name' in training_configuration['global']:
                cluster_name = training_configuration['global']['cluster_name']

        # Check if specific cluster name exists
        if training:
            if 'training' in training_configuration:
                if 'cluster_name' in training_configuration['training']:
                    cluster_name = \
                        training_configuration['training']['cluster_name']
                if 'cluster_type' in training_configuration['training']:
                    cluster_type = \
                        training_configuration['training']['cluster_type']
                    # Validate two possible values
                    if cluster_type == MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CLUSTER:
                        compute_cluster_type = cluster_type
                    else:
                        if cluster_type == MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CI:
                            compute_cluster_type = cluster_type
                            
        if cluster_name is None:
            raise MLOTrainingConfigurationException(
                "Error, cluster name not found in configuration.")

        return compute_cluster_type, cluster_name

    @staticmethod
    def aml_hyperparameters_from_dict(hyperparameters_dict: dict,
                                      prefix: str = None):
        """Convert from dict struture to HyperParameter AML Object.

        Parses dict loaded from external source (such as YAML) and
        return their representation into HyperParameterSampling
        AML Object. Currently only supports "GridParameterSampling".

        @See: https://docs.microsoft.com/en-us/python/api/azureml-train-core/azureml.train.hyperdrive.gridparametersampling?view=azure-ml-py
        @See: https://docs.microsoft.com/en-us/python/api/azureml-train-core/azureml.train.hyperdrive.hyperparametersampling?view=azure-ml-py

        Args:
            prefix (str): Optional prefix to add parameter names
            hyperparameters_dict (dict): Python dictionary containing
                hyperparameter configuration

                Example of input:

                    {
                        'GridParameterSampling': {
                            'n_jobs': {'choice': [20]},
                            'n_estimators': {'choice': [1]},
                            'min_samples_leaf': {'choice': {
                                                    'range': [3, 8]}
                                                },
                            'alpha': {'choice': [0.1, 0.2]}
                        }
                    }

        Returns:
            ParameterExpresion: The AML parameter expression to launch
                Hyperparameter trainings
        """
        hyperparameter_config_azml_dict = {}
        hyperparameter_config_azml = None
        hyperparameters_config_types = {}
        samplings = hyperparameters_dict
        for sampling in samplings:
            if sampling.lower() == "GridParameterSampling".lower():
                # Pase parameter space
                parameter_spaces = samplings[sampling]
                for parameter_space in parameter_spaces:
                    parameter_space_name = parameter_space
                    if prefix is not None:
                        parameter_space_name = prefix + parameter_space_name
                    parameter_space_value_types = parameter_spaces[parameter_space]
                    for parameter_space_value_type in parameter_space_value_types:
                        # Parsing choice values
                        if parameter_space_value_type.lower() == "choice".lower():
                            parameter_space_value = parameter_space_value_types[parameter_space_value_type]
                            if isinstance(parameter_space_value, list):
                                # Find a list. build directly the choice object
                                hyperparameter_config_azml_dict[parameter_space_name] = choice(
                                    parameter_space_value)

                                # Check type for the first element of the list
                                hyperparameters_config_types[parameter_space_name] = MLOHypermetersConfigTypes.get(
                                    parameter_space_value[0]).name

                            elif isinstance(parameter_space_value, dict):
                                parameter_space_value_subtypes = parameter_space_value
                                for parameter_space_value_subtype in parameter_space_value_subtypes:
                                    # Parsing range values
                                    if parameter_space_value_subtype.lower() == "range".lower():
                                        range_limits = parameter_space_value_subtypes[
                                            parameter_space_value_subtype]
                                        hyperparameter_config_azml_dict[parameter_space_name] = choice(
                                            range(range_limits[0], range_limits[1]+1))

                                        # Check type for the first element of the list
                                        hyperparameters_config_types[parameter_space_name] = MLOHypermetersConfigTypes.get(
                                            range_limits[0]).name

                # Create Sampling
                hyperparameter_config_azml = GridParameterSampling(
                    hyperparameter_config_azml_dict)

        return hyperparameter_config_azml, hyperparameters_config_types

    @staticmethod
    def aml_hyperparameters_from_yaml(hyperparameters_yaml: str,
                                      prefix: str = None):
        """Load HyperParameter AML Object from YAML file.

        Parses YAML and it returns their representation into
        HyperParameterSampling AML Object. Currently only
        supports "GridParameterSampling".

        @See: https://docs.microsoft.com/en-us/python/api/azureml-train-core/azureml.train.hyperdrive.gridparametersampling?view=azure-ml-py
        @See: https://docs.microsoft.com/en-us/python/api/azureml-train-core/azureml.train.hyperdrive.hyperparametersampling?view=azure-ml-py

        Args:
            prefix (str): Optional prefix to add parameter names
            hyperparameters_yaml (str): YAML file containing
                hyperparameter configuration

            Example of YAML input:

                GridParameterSampling:
                    n_jobs:
                        choice:
                        - 20
                    n_estimators:
                        choice:
                        - 1
                    # Concurrency working with Rand.Forest building each tree
                    min_samples_leaf:
                        choice:
                        range:
                            - 3
                            - 8
                    alpha:
                        choice:
                        - 0.1
                        - 0.2

        Returns:
            ParameterExpresion: The AML parameter expression to launch
                Hyperparameter trainings. Returns 'None' if the file
                doesn't contain data.
        """
        path = Path(hyperparameters_yaml)
        yaml = YAML(typ='safe')
        hyperparameters_config = yaml.load(path)

        if hyperparameters_config is None or len(hyperparameters_config) == 0:
            return None

        return MLOTrainingConfiguration.\
            aml_hyperparameters_from_dict(hyperparameters_config, prefix)

    @staticmethod
    def dataset_from_yaml(training_configuration: str,
                          ds_version: int = 0,
                          ds_train_name: str = None,
                          ds_test_name: str = None,
                          ds_evaluation_name: str = None):
        """Return dataset configuration parameters for DevOps/MLOps scripts

        Return dataset configuration parameters and set default values if
        they are not present in the configuration and they are not passed
        as input values.

        Args:
            training_configuration (str): File path containing training configuration. Defaults to None.
            ds_version (str, optional): Registered dataset version for training, test and evaluation. Defaults to None.
            ds_train_name (str, optional): Registered train dataset name. Defaults to None.
            ds_test_name (str, optional): Registered test dataset name. Defaults to None.
            ds_evaluation_name (str, optional): Registered evaluation dataset name. Defaults to None.

        Returns:
            ds_version (str, optional): Registered dataset version for training, test and evaluation. Defaults to None.
            ds_train_name (str, optional): Registered train dataset name. Defaults to None.
            ds_test_name (str, optional): Registered test dataset name. Defaults to None.
            ds_evaluation_name (str, optional): Registered evaluation dataset name. Defaults to None.

        Raises:
            ValueError: training configuration file path is not provided
        """

        if training_configuration is None or not training_configuration.strip:
            raise ValueError(
                "Error, training configuracion path is not provided")

        # Load model and dataset data from YAML config file
        path = Path(training_configuration)
        yaml = YAML(typ='safe')
        train_config = yaml.load(path)

        if 'dataset' in train_config:
            if 'version' in train_config['dataset']:
                ds_version = train_config['dataset']['version']
            if 'train' in train_config['dataset']:
                ds_train_name = train_config['dataset']['train']
            if 'test' in train_config['dataset']:
                ds_test_name = train_config['dataset']['test']
            if 'evaluation' in train_config['dataset']:
                ds_evaluation_name = train_config['dataset']['evaluation']

        return ds_version, ds_train_name, ds_test_name, ds_evaluation_name

    @staticmethod
    def single_params_from_yaml(training_configuration: str = None):
        """Return configuration parameters for single training execution

        Returns configuration parameters in case of single training execution.
        These parameters are available to the Datascientist in the
        "extra_params" argument of the train function. The specification
        of these values from the training configuration file are into the
        "single_parameter" section. Each "key" of the list is a parameter
        and their type is infered from their value. These parameters are
        returned as a dict. Also, return the types of these paraemters.

        If no configuration parameters are defined, it returns empty dict.

        Example:

        # Configuration parameters for single training.
        # These parameters are not taken into an account for hyperparameter
        # tunning
        single_parameter:
            - max_depth_space: 5
            - n_estimators_space: 50
            - learning_rate_space: 0.5

        """
        single_parameter = {}
        single_parameter_types = {}

        if training_configuration is not None:
            # Load model and dataset data from YAML config file
            path = Path(training_configuration)
            yaml = YAML(typ='safe')
            train_config = yaml.load(path)

            if 'single_parameter' in train_config['training']:
                for parameter in train_config['training']['single_parameter']:
                    single_parameter.update(parameter)

            for parameter in single_parameter:
                parameter_name = parameter
                single_parameter_types[parameter_name] = \
                    MLOSingleParametersConfigTypes. \
                    get(single_parameter[parameter])

        return single_parameter, single_parameter_types

    @staticmethod
    def hyperparameters_value_params_from_yaml(
            hyperparameters_configuration: str,
            hyperparameters_config=None):
        """Return hyperparameter value parameters for DevOps/MLOps scripts

        Read hyperparameter config file and set default values if
        they are not present in the configuration and they are not passed
        as input values.

        Args:
            hyperparameters_configuration (str): File path
                containing hyperparameters value spefication. Defaults toNone
            hyperparameters_config (dict, optional): Hyperparameter
                values with default values. Defaults to None.

        Returns:
            hyperparameters_config (dict, optional): Hyperparameter values
                    with default values. Defaults to None.

        Raises:
            ValueError: if the file is None

        """

        # Load hyperparameters tunning if exists
        hyperparameters_config_types = None
        hyperparameters_config = None
        # Check for Hyperparameter configuration
        if hyperparameters_configuration is None or \
                not hyperparameters_configuration.strip():
            raise ValueError(
                "Error, no hyperparameter training file provided.")

        # Load hyperparameters data from YAML config file
        hyperparameters_config, hyperparameters_config_types = \
            MLOTrainingConfiguration.aml_hyperparameters_from_yaml(
                hyperparameters_configuration)

        return hyperparameters_config, hyperparameters_config_types

    @staticmethod
    def hyperparameters_params_from_yaml(training_configuration: str = None,
                                         training_hyperparameter_metric: str = 'accuracy',
                                         training_hyperparameter_goal=PrimaryMetricGoal.MINIMIZE):
        """Return hyperparameter configuration parameters for DevOps/MLOps scripts

        Return hyperparameter configuration parameters and set default values if
        they are not present in the configuration and they are not passed
        as input values.

        Args:
            training_configuration (str, optional): File path containing training configuration. Defaults to None.
            training_hyperparameter_metric (str, optional): Metric reference to compare hyperparameter training.
                Defaults to 'accuracy'.
            training_hyperparameter_goal ([type], optional): In order to get the best model provided, this parameter
                indicates the goal for the metric reference. Defaults to PrimaryMetricGoal.MINIMIZE.

         Returns:

            training_hyperparameter_metric (str, optional): Metric reference to compare hyperparameter training.
                Defaults to 'accuracy'.
            training_hyperparameter_goal ([type], optional): In order to get the best model provided, this parameter
                indicates the goal for the metric reference. Defaults to PrimaryMetricGoal.MINIMIZE.
        """
        training_hyperparameter_metric = None
        training_hyperparameter_goal = None

        if training_configuration is not None:
            # Load model and dataset data from YAML config file
            path = Path(training_configuration)
            yaml = YAML(typ='safe')
            train_config = yaml.load(path)

            if 'training' in train_config:
                if 'hyperparameter' in train_config['training']:
                    if 'primary_metric_name' in train_config['training']['hyperparameter']:
                        training_hyperparameter_metric = train_config[
                            'training']['hyperparameter']['primary_metric_name']
                    if 'primary_metric_goal' in train_config['training']['hyperparameter']:
                        if train_config['training']['hyperparameter']['primary_metric_goal'] == 'PrimaryMetricGoal.MINIMIZE':
                            training_hyperparameter_goal = train_config['training'][
                                'hyperparameter'] = PrimaryMetricGoal.MINIMIZE
                        else:
                            training_hyperparameter_goal = train_config['training'][
                                'hyperparameter'] = PrimaryMetricGoal.MAXIMIZE

        return training_hyperparameter_metric, training_hyperparameter_goal
