#!/usr/bin/env python3
from .mloentrypoint import MLOEntrypoint


def main():
    # Parse arguments and execute MLOPs Operation
    MLOEntrypoint.do()


if __name__ == '__main__':
    main()
