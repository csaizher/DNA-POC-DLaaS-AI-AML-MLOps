#!/usr/bin/env python3
from amlops.mlooperations import MLOOperations
from amlops.mloutils import MLOUtils
import argparse
import os

from amlops.configuration.mlotrainingconfiguration import MLOTrainingConfiguration
from amlops.configuration.mlotrainingconfiguration import MLOTrainingTypes
from amlops.configuration.mloconfiguration import MLOConfiguration
from amlops.configuration.mloinferenceconfiguration import MLOInferenceConfiguration


class MLOEntrypoint():
    """Entrypoint for MLOperations.

    Entrypoint for invoking mlops operations from the pipelines. So
    you can invoke using 'python -m'

    Requires the installation of "azureml-dataset-runtime[fuse,pandas]"
    pip install azureml-dataset-runtime[fuse,pandas]

    """

    @staticmethod
    def do():
        """Parse input options and execute the mlops operation.

        It parses input arguments from commandline and it executes
        the mlops requested operation. Syntax for these operations are:

            Option "deploy-model-batch": Publishes a model. Contains the
            following subparameters:
                -g RESOURCE_GROUP, --resource-group RESOURCE_GROUP
                                        Associated resource group with the
                                        Azure ML workspace
                -w WORKSPACE_NAME, --workspace-name WORKSPACE_NAME
                                        Workspace associted to the deploy

                -s SUBSCRIPTION, --subscription SUBSCRIPTION
                                        Associated subscription with the Azure
                                        ML workspace
                -en ENVIRONMENT_NAME, --environment-name ENVIRONMENT_NAME
                                        Environment name to create or update
                                        for using with this training
                -d DOCKERFILE, --dockerfile DOCKERFILE
                                        Dockerfile containing train python
                                        extra libraries
                -ds DOCKERFILE_SOURCE, --dockerfile-source DOCKERFILE_SOURCE
                                        Docker source folder containing the
                                        items to be included into the docker
                                        image
                -ic INFERENCE_CONFIGURATION, --inference-configuration
                                        INFERENCE_CONFIGURATION
                                        Consuming configuration including
                                        model parameters
                -af ARTIFACT_FOLDER, --artifact-folder ARTIFACT_FOLDER
                                        Artifact to share metadata for later
                                        steps


            Option "train-model": Launch a training. Contains the following
            subparameters:

                -g RESOURCE_GROUP, --resource-group RESOURCE_GROUP
                                        Associated resource group with the
                                        Azure ML workspace
                -w WORKSPACE_NAME, --workspace-name WORKSPACE_NAME
                                        AzureML workspace name containing
                                        training artifacts
                -s SUBSCRIPTION, --subscription SUBSCRIPTION
                                        Associated subscription with the
                                        Azure ML workspace
                -en ENVIRONMENT_NAME, --environment-name ENVIRONMENT_NAME
                                        Environment name to create or update
                                        for using with this training
                -d DOCKERFILE, --dockerfile DOCKERFILE
                                        Dockerfile containing train python
                                        extra libraries
                -ds DOCKERFILE_SOURCE, --dockerfile-source DOCKERFILE_SOURCE
                                        Docker source folder containing the
                                        items to be included into the docker
                                        image
                -e EXPERIMENT_NAME, --experiment-name EXPERIMENT_NAME
                                        Name of the experiment
                -tc TRAINING_CONFIGURATION, --training-configuration
                                        TRAINING_CONFIGURATION
                                        Training configuration including
                                        dataset and model parameters
                -hc HYPERPARAMETERS_CONFIGURATION,
                                        --hyperparameters-configuration
                                        HYPERPARAMETERS_CONFIGURATION
                                        Hyperparameters configuration file

            Option "test-aml-connection": perform a test connection against
            the workspace as a smoke test. Contains the following
            subparameters:

                -g RESOURCE_GROUP, --resource-group RESOURCE_GROUP
                        Associated resource group with the Azure ML workspace

                -w WORKSPACE_NAME, --workspace-name WORKSPACE_NAME
                        Workspace associted to the deploy

                -s SUBSCRIPTION, --subscription SUBSCRIPTION
                        Associated subscription with the Azure ML workspace
        Args:

        Returns:

        """

        # Initialize parser
        info = "MLOps deployment support tool"
        parser = argparse.ArgumentParser(description=info)
        subparsers = parser.add_subparsers(dest='command')

        # Define arguments for deploying with Batch
        deploy_model_batch_parser = subparsers.add_parser("deploy-model-batch")
        deploy_model_batch_parser.add_argument(
            "-g", "--resource-group",
            help="Associated resource group with the Azure ML workspace",
            required=True)
        deploy_model_batch_parser.add_argument(
            "-w", "--workspace-name", help="Workspace associted to the deploy",
            required=True)
        deploy_model_batch_parser.add_argument(
            "-s", "--subscription",
            help="Associated subscription with the Azure ML workspace",
            required=True)
        deploy_model_batch_parser.add_argument(
            "-en", "--environment-name",
            help="Environment name to create or update for using with \
                this training",
            required=True)
        deploy_model_batch_parser.add_argument(
            "-d",
            "--dockerfile", help="Dockerfile containing train python \
                extra libraries",
            required=True)
        deploy_model_batch_parser.add_argument(
            "-ds", "--dockerfile-source",
            help="Docker source folder containing the items to be \
                included into the docker image", required=True)
        deploy_model_batch_parser.add_argument(
            "-ic", "--inference-configuration",
            help="Consuming configuration including model parameters",
            required=False)
        deploy_model_batch_parser.add_argument(
            "-af", "--artifact-folder",
            help="Artifact to share metadata for later steps", required=False)

        # Define arguments for training
        train_model_parser = subparsers.add_parser("train-model")
        train_model_parser.add_argument(
            "-g", "--resource-group",
            help="Associated resource group with the Azure ML workspace",
            required=True)
        train_model_parser.add_argument(
            "-w", "--workspace-name",
            help="AzureML workspace name containing training artifacts",
            required=True)
        train_model_parser.add_argument(
            "-s", "--subscription",
            help="Associated subscription with the Azure ML workspace",
            required=True)
        train_model_parser.add_argument(
            "-en", "--environment-name",
            help="Environment name to create or update for using with \
                this training",
            required=True)
        train_model_parser.add_argument(
            "-d", "--dockerfile",
            help="Dockerfile containing train python extra libraries",
            required=True)
        train_model_parser.add_argument(
            "-ds", "--dockerfile-source",
            help="Docker source folder containing the items to be included \
                into the docker image",
            required=True)
        train_model_parser.add_argument(
            "-e", "--experiment-name",
            help="Name of the experiment", required=True)
        train_model_parser.add_argument("-tc", "--training-configuration",
                                        help="Training config including \
                                            dataset and model params",
                                        required=False)
        train_model_parser.add_argument(
            "-hc", "--hyperparameters-configuration",
            help="Hyperparameters configuration file", required=False)

        # Define arguments for testing AzureML workspace access
        test_aml_connection = subparsers.add_parser("test-aml-connection")
        test_aml_connection.add_argument(
            "-g",
            "--resource-group",
            help="Associated resource group with the Azure ML workspace",
            required=True)
        test_aml_connection.add_argument(
            "-w", "--workspace-name",
            help="Workspace associted to the deploy", required=True)
        test_aml_connection.add_argument(
            "-s", "--subscription",
            help="Associated subscription with the Azure ML workspace",
            required=True)

        args = parser.parse_args()

        if args.command == 'test-aml-connection':
            MLOUtils().test_aml_connection(args.subscription,
                                           args.resource_group,
                                           args.workspace_name)

        if args.command == 'train-model':

            model_name = None
            model_description = None
            model_version = None

            if args.training_configuration is None:
                raise Exception("Error, training configuration file found.")

            # Load hyperparameter configuration
            training_hyperparameter_metric, training_hyperparameter_goal = MLOTrainingConfiguration.hyperparameters_params_from_yaml(
                args.training_configuration)

            # Load model configuration
            model_name, model_description, model_version = MLOConfiguration.model_params_from_yaml(
                args.training_configuration)

            # Model version not needed for training
            model_version = None

            # Load dataset configuration
            ds_version, ds_train_name, ds_test_name, ds_evaluation_name = MLOTrainingConfiguration.dataset_from_yaml(
                args.training_configuration)

            # Load other related configuration
            compute_cluster_type, cluster_name = MLOTrainingConfiguration.cluster_from_yaml(
                args.training_configuration, training=True)

            # Load parameters for the single training
            single_parameters, single_parameter_types = MLOTrainingConfiguration.single_params_from_yaml(
                args.training_configuration)

            # Load training type
            training_type = MLOTrainingConfiguration.train_type_from_yaml(
                args.training_configuration)

            # Load hyperparameters
            hyperparameters_config, hyperparameters_config_types = MLOTrainingConfiguration.hyperparameters_value_params_from_yaml(
                args.hyperparameters_configuration)

            # Load other execution parameters
            show_output = MLOTrainingConfiguration.execution_params_from_yaml(args.training_configuration)

            # Launch training

            # Check non-valid values
            if model_name is None or model_description is None:
                raise Exception("Error, no model name or description provided")

            print("TIPO DE ENTRENAMIENTO: " + str(training_type))

            if training_type == MLOTrainingTypes.HYPERPARAMETER:
                MLOOperations.train_model_multi(args.subscription,
                                                args.resource_group,
                                                args.workspace_name,
                                                args.environment_name,
                                                args.dockerfile,
                                                args.dockerfile_source,
                                                args.experiment_name,
                                                model_name, model_description,
                                                ds_version, ds_train_name,
                                                ds_test_name,
                                                ds_evaluation_name,
                                                hyperparameters_config,
                                                hyperparameters_config_types,
                                                training_hyperparameter_metric,
                                                training_hyperparameter_goal,
                                                cluster_name)
            else:
                if training_type == MLOTrainingTypes.SINGLE:
                    MLOOperations.train_model(args.subscription,
                                              args.resource_group,
                                              args.workspace_name,
                                              args.environment_name,
                                              args.dockerfile,
                                              args.dockerfile_source,
                                              args.experiment_name, model_name,
                                              model_description,
                                              ds_version, ds_train_name,
                                              ds_test_name, ds_evaluation_name,
                                              single_parameters,
                                              single_parameter_types,
                                              cluster_name,
                                              compute_cluster_type,
                                              show_output)
                else:
                    raise ValueError("The type of training is not valid.")

        if args.command == 'deploy-model-batch':

            if args.inference_configuration is not None:

                model_name = None
                model_description = None
                model_version = None

                # Load default specific consuming configuration
                model_inference_parameters, inference_dataset_datatypes, \
                    batch_size, process_count_per_node, node_count, \
                    run_invocation_timeout, cluster_name, environment_name, \
                    output_inference_columns, pipeline_name, \
                    pipeline_description = \
                    MLOInferenceConfiguration.inference_params_from_yaml(
                        args.inference_configuration)

                # Load model configuration
                model_name, model_description, model_version = \
                    MLOConfiguration.model_params_from_yaml(
                        args.inference_configuration)

                mlops_source = args.dockerfile_source + "/../mlops"

                print("Deploying inference model with SUS - RG - WS")
                print(args.subscription)
                print(args.resource_group)
                print(args.workspace_name)
                print(args.artifact_folder)

                published_pipeline = MLOOperations.deploy_model_batch(
                    args.subscription, args.resource_group,
                    args.workspace_name, environment_name,
                    args.dockerfile, args.dockerfile_source, mlops_source,
                    model_name, model_version, model_inference_parameters,
                    inference_dataset_datatypes, batch_size,
                    process_count_per_node, node_count, run_invocation_timeout,
                    cluster_name, output_inference_columns,
                    pipeline_name, pipeline_description)

                # Write pipeline information in an output file
                print(f"Saving pipeline id {published_pipeline.id} to working directory: \
                    {args.artifact_folder}")

                pipeline_id_filepath = os.path.join(
                    args.artifact_folder, "pipeline.id")
                pipeline_id_file = open(pipeline_id_filepath, "w")
                pipeline_id_file_content = \
                    "##vso[task.setvariable variable=AML_PIPELINE_ID;isSecret=false;isOutput=true;]"\
                    + published_pipeline.id
                pipeline_id_file_content = published_pipeline.id
                print(f"New pipeline ID generated with value \
                    {pipeline_id_file_content}")
                pipeline_id_file.write(pipeline_id_file_content)
                pipeline_id_file.flush()
                pipeline_id_file.close()
