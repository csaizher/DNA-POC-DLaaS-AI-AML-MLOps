# Support for MLOPs operations such as Training or Inference
from azureml.core import (Dataset, Experiment, ScriptRunConfig)
from azureml.core.compute import (ComputeTarget)
from azureml.core.runconfig import DockerConfiguration, MpiConfiguration
from azureml.train.hyperdrive.run import PrimaryMetricGoal
# @See https://github.com/Azure/MachineLearningNotebooks/blob/master/how-to-use-azureml/ml-frameworks/scikit-learn/train-hyperparameter-tune-deploy-with-sklearn/train-hyperparameter-tune-deploy-with-sklearn.ipynb
from azureml.train.hyperdrive.runconfig import HyperDriveConfig
from azureml.pipeline.core import Pipeline
from azureml.pipeline.core import PipelineParameter

from .mlocompute import MLOCompute, MLOComputeConstants
from .mlocore import MLOCore
from .mlopipelines import MLOPipelines

# This is only to show the progress when you are on notebooks
# from azureml.widgets import RunDetails

class MLOOperations:

    @staticmethod
    def getModelOutputFile():
        return "outputs/model/model.pkl"

    @staticmethod
    def getModelOutputDir():
        return "outputs/model"

    @staticmethod
    def train_model_multi(
            subscription, resource_group, workspace_name, environment_name,
            dockerfile, dockerfile_source, experiment_name, model_name,
            model_description, ds_version, ds_train_name, ds_test_name,
            ds_evaluation_name, hyperparameters=None,
            hyperparameters_config_types=None,
            training_hyperparameter_metric: str = 'accuracy',
            training_hyperparameter_goal=PrimaryMetricGoal.MAXIMIZE,
            compute_cluster_name: str = None):
        """Performs multiple model trainings based on several hyperparameters configurations.

        Note: identity System Assigned is used in order to have ACRPull permissions when working with Docker

        Args:
            subscription (string): Associated subscription with the Azure ML workspace
            resource_group (string): Associated resource group with the Azure ML workspace
            workspace_name (string): AzureML workspace name containing training artifacts
            environment_name (string): Environment name to create or update for using with this training
            dockerfile (string): Dockerfile containing train python extra libraries
            dockerfile_source (string): Docker source folder containing the items to be included into the docker image
            experiment_name (string): Name of the AzureML experiment
            model_name (string): Name used for registering the model
            model_description (string): Description of the model to be registered
            hyperparameters (list): list of hiperparameters to iterate and launch a new trainning
            hyperparameters_config_types (dict): key-value pairs contining the name of the hyperparameter and the data type
            compute_cluster_name (str): Name of existing compute cluster. If it is none or it doesn't exists, it will create a new one with default parameters
        See also:
            https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.core.compute.amlcompute(class)?view=azure-ml-py

        """

        # Get workspace
        workspace = MLOCore.get_workspace(
            subscription, resource_group, workspace_name)

        # Update or create environment
        environment = MLOCore.create_or_update_environment(
            workspace, environment_name, dockerfile, docker_args=None)

        # Cluster provisioning

        # Number of executions from hyperparameters configuration
        # TODO: Review this hardcoded value: i.e. calulate "number_iterations = len(hyperparameters)"
        number_iterations = 10

        cluster = MLOCompute.get_training_compute(
            workspace,
            cluster_name=compute_cluster_name,
            min_nodes=MLOComputeConstants.DEFAULT_MIN_NODES_TRAINING,
            max_nodes=number_iterations)

        dist_config = MpiConfiguration(node_count=1, process_count_per_node=2)

        experiment = Experiment(workspace, experiment_name)

        # TODO: Parametrize cluster/docker configuration
        docker_config = DockerConfiguration(use_docker=True, shm_size='8g')

        model_filename = "model.pkl"

        # Launch job
        arguments = ["train-model", "-s", subscription, "-g",
                     resource_group, "-w", workspace_name, "-e",
                     experiment_name, "-m", model_filename]

        # Add dataset information if available
        if ds_version is not None:
            ds_version = int(str(ds_version))
        if ds_train_name is not None:
            arguments.append("-da")
            ds_train = Dataset.get_by_name(
                workspace, name=ds_train_name, version=ds_version)
            arguments.append(ds_train.as_named_input('ds_train'))
        if ds_test_name is not None:
            arguments.append("-dt")
            ds_test = Dataset.get_by_name(
                workspace, name=ds_test_name, version=ds_version)
            arguments.append(ds_test.as_named_input('ds_test'))
        if ds_evaluation_name is not None:
            arguments.append("-de")
            ds_evaluation = Dataset.get_by_name(
                workspace, name=ds_evaluation_name, version=ds_version)
            arguments.append(ds_evaluation.as_named_input('ds_evaluation'))

        # Add Hyperparameters data types as parameters
        hyperparameters_config_types
        for hyperparameter in hyperparameters_config_types:
            arguments.append("--" + hyperparameter + "-type")
            arguments.append(hyperparameters_config_types[hyperparameter])

        print("Final ARGS: " + str(arguments))

        print("Launching job")
        jobconfig = ScriptRunConfig(
            source_directory=dockerfile_source,
            script="./train.py",
            arguments=arguments,
            compute_target=cluster,
            environment=environment,
            distributed_job_config=dist_config,
            docker_runtime_config=docker_config
        )

        # Hyperparameter Launching
        hyperdrive_config = \
            HyperDriveConfig(run_config=jobconfig,
                             hyperparameter_sampling=hyperparameters,
                             # policy=early_termination_policy,
                             primary_metric_name=training_hyperparameter_metric,
                             primary_metric_goal=training_hyperparameter_goal,
                             max_total_runs=20,
                             max_concurrent_runs=10)

        # Submit the hyperdrive run
        # Note: No RUN is RETURNED, a HYPERDRIVE RUN instead is RETURNED
        hyperdrive_run = experiment.submit(config=hyperdrive_config)

        # Wait until it is finished
        hyperdrive_run.wait_for_completion(show_output=True)

        # TODO: Check error control
        print("Status after runnning hyperdrive: " +
              hyperdrive_run.get_status())
        # assert(hyperdrive_run.get_status() == "Completed")

        # Register N models
        hyperdrive_child_runs = hyperdrive_run.get_children()

        for child_run in hyperdrive_child_runs:
            print(
                f"Registering Model {model_name} for run with id {child_run.id}\
                and name {child_run.display_name} ")

            # Register the model
            # the model folder produced from the run is registered. This includes the MLmodel file, model.pkl and the conda.yaml.
            #run.register_model(model_name = 'my-model', model_path = 'model')
            # "run" is a reference to a completed experiment run
            # Download a named file
            model_path = 'model/{}'.format(model_filename)

            model_path = MLOOperations.getModelOutputFile()

            # Check if model framework is defined
            model_framework = None
            model_framework_version = None
            if 'model_framework' in child_run.get_properties():
                model_framework = child_run.get_properties()['model_framework']
                if 'model_framework_version' in child_run.get_properties():
                    model_framework_version = child_run.get_properties()[
                        'model_framework_version']

            # Register model. The model is returned when register, but
            # at the moment model is not used.
            # i.e. model = child_run.register_model(model_name=model_name ...
            child_run.register_model(model_name=model_name,
                                     model_path=model_path,
                                     description=model_description,
                                     tags={'stage': 'training'},
                                     model_framework=model_framework,
                                     model_framework_version=model_framework_version
                                     )

    @staticmethod
    def train_model(subscription, resource_group, workspace_name,
                    environment_name, dockerfile, dockerfile_source,
                    experiment_name, model_name,  model_description,
                    ds_version, ds_train_name, ds_test_name,
                    ds_evaluation_name, single_parameters,
                    single_parameter_types,
                    compute_cluster_name: str = None,
                    compute_cluster_type: str = MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CLUSTER,
                    show_output = True):
        """Train a model with specific environment.

        Note: identity System Assigned is used in order to have ACRPull
        permissions when working with Docker

        Args:
            subscription (str): Associated subscription with the Azure ML workspace
            resource_group (str): Associated resource group with the Azure ML workspace
            workspace_name (str): AzureML workspace name containing training artifacts
            environment_name (str): Environment name to create or update for using with this training
            dockerfile (str): Dockerfile containing train python extra libraries
            dockerfile_source (string): Docker source folder containing the items to be included into the docker image
            experiment_name (string): Name of the AzureML experiment
            model_name (str): Name used for registering the model
            model_description (str): Description of the model to be registered
            single_parameters (dict): extra parameters for the single training
            compute_cluster_name (str): Name of existing compute cluster. If
                it is none or it doesn't exists, it will create a new one with
                default parameters
            compute_cluster_type(str): Type of compute. Use Compute Cluster o use
                Compute Instance. For Compute Cluster Use MLOComputeConstants.
                COMPUTE_CLUSTER_TYPE_CLUSTER. For Computer Instance, use 
                MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CI
            show_output (bool): Show or not the output thought the default output for the experiment when running

        See also:
            https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.core.compute.amlcompute(class)?view=azure-ml-py

        """

        # Get workspace
        workspace = MLOCore.get_workspace(
            subscription, resource_group, workspace_name)

        # Update or create environment
        environment = MLOCore.create_or_update_environment(
            workspace, environment_name, dockerfile, docker_args=None)

        print("Environment creado. Creando cluster")

        # Cluster provisioning
        cluster = \
            MLOCompute.get_training_compute(workspace=workspace,
                                            cluster_name=compute_cluster_name, 
                                            compute_cluster_type=compute_cluster_type)

        if compute_cluster_type == MLOComputeConstants.COMPUTE_CLUSTER_TYPE_CLUSTER:
            dist_config = MpiConfiguration(node_count=1, process_count_per_node=2)
        else:
            dist_config = None

        print("Compute creada. Creando experiemento de entrenamient con nombre " + experiment_name)
        experiment = Experiment(workspace, experiment_name)

        # TODO: Parametrize cluster/docker configuration
        docker_config = DockerConfiguration(use_docker=True, shm_size='8g')

        model_filename = "model.pkl"

        # Launch job
        arguments = ["train-model", "-s", subscription, "-g",
                     resource_group, "-w", workspace_name, "-e",
                     experiment_name, "-m", model_filename]

        # Add dataset information if available
        if ds_version is not None:
            ds_version = int(str(ds_version))
        if ds_train_name is not None:
            arguments.append("-da")
            ds_train = Dataset.get_by_name(
                workspace, name=ds_train_name, version=ds_version)
            arguments.append(ds_train.as_named_input('ds_train'))
        if ds_test_name is not None:
            arguments.append("-dt")
            ds_test = Dataset.get_by_name(
                workspace, name=ds_test_name, version=ds_version)
            arguments.append(ds_test.as_named_input('ds_test'))
        if ds_evaluation_name is not None:
            arguments.append("-de")
            ds_evaluation = Dataset.get_by_name(
                workspace, name=ds_evaluation_name, version=ds_version)
            arguments.append(ds_evaluation.as_named_input('ds_evaluation'))

        # Add single parameters values and types
        for parameter in single_parameter_types:
            # Add value type
            arguments.append("--" + parameter + "-type")
            arguments.append(single_parameter_types[parameter].name)
            # Add value parameter
            arguments.append("--" + parameter)
            arguments.append(single_parameters[parameter])

        print("Launching job")
        print("Arguments: " + str(arguments))
        print("Lanzando JOB ")
        jobconfig = ScriptRunConfig(
            source_directory=dockerfile_source,
            script="./train.py",
            arguments=arguments,
            compute_target=cluster,
            environment=environment,
            distributed_job_config=dist_config,
            docker_runtime_config=docker_config
        )

        # Submit the run
        print("Creando run ")
        run = experiment.submit(config=jobconfig)
        print("Esperando a que finalice el run ")
        run.wait_for_completion(show_output=show_output)
        print("Experimento finalizado ")

        # Register the model
        # the model folder produced from the run is registered. This includes
        # the MLmodel file, model.pkl and the conda.yaml.
        # run.register_model(model_name = 'my-model', model_path = 'model')
        # "run" is a reference to a completed experiment run
        # Download a named file
        model_path = 'model/{}'.format(model_filename)

        model_path = MLOOperations.getModelOutputFile()

        # Check if model framework is defined
        model_framework = None
        model_framework_version = None
        if 'model_framework' in run.get_properties():
            model_framework = run.get_properties()['model_framework']
            if 'model_framework_version' in run.get_properties():
                model_framework_version = run.get_properties()[
                    'model_framework_version']

        run.register_model(model_name=model_name,
                           model_path=model_path,
                           description=model_description,
                           tags={'stage': 'training'},
                           model_framework=model_framework,
                           model_framework_version=model_framework_version

                           )

    @staticmethod
    def deploy_model_batch(
            subscription, resource_group, workspace_name, environment_name,
            dockerfile, dockerfile_source, mlops_source,
            model_name, model_version, model_inference_parameters, inference_dataset_datatypes,
            batch_size, process_count_per_node, node_count, run_invocation_timeout, cluster_name, output_inference_columns,
            pipeline_name, pipeline_description):
        """Performs model inference from input file with requests and generate an output file with predictions.

        Args:
            subscription (str): Associated subscription with the Azure ML workspace
            resource_group (str): Associated resource group with the Azure ML workspace
            workspace_name (str): AzureML workspace name containing training artifacts
            environment_name (str): Environment name to create or update for using with this training
            dockerfile (str): Dockerfile containing inference python extra libraries
            dockerfile_source (str): Docker source folder containing the items to be included into the docker image,
            mlops_source (str): Docker source folder containing the items to be included into the docker image for the register step,
            model_name (str): Model name used for the inference
            model_version (str): Model version used for the inference
            model_inference_parameters (str): Extra custom parameters required for the inference
            inference_dataset_datatypes (str): column datatypes for the input tabular file in JSON string format
            batch_size (str): Batch size of the inference
            process_count_per_node (int): Number of parallel processes by node
            node_count (int): Number of nodes of the cluster
            run_invocation_timeout (int): timeout value for a inference computation for one process
            cluster_name (str): Name of existing compute cluster. If it is none or it doesn't exists, it will create a new one with default parameters
        See also:
            https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.core.compute.amlcompute(class)?view=azure-ml-py

        """

        from amlops.mlocore import MLOCore

        # Get workspace
        workspace = MLOCore.get_workspace(
            subscription, resource_group, workspace_name)

        print("Prepare pipelines")
        # Definition of the Pipeline parameters
        # Input file. Contains requests from which scorings are going to be
        # performed
        pp_input_filepath = PipelineParameter(
            name="input_filepath",
            default_value='raw/use-case/dataset/inference_file.csv')
        pp_input_datastore = PipelineParameter(
            name="input_datastore", default_value='workspaceblobstore')

        # Output file. Contains predictions done from the requests
        pp_output_filepath = PipelineParameter(
            name="output_filepath", default_value='')
        pp_output_datastore = PipelineParameter(
            name="output_datastore", default_value='')

        # Output columns
        pp_output_inference_columns = PipelineParameter(
            name="output_inference_columns",
            default_value=output_inference_columns)

        # Model name and version
        pp_model_name = PipelineParameter(
            name="model_name", default_value=model_name)
        pp_model_version = PipelineParameter(
            name="model_version", default_value=model_version)

        # Technical execution parameters
        pp_batch_size = PipelineParameter(
            name="batch_size", default_value=batch_size)
        pp_node_count = PipelineParameter(
            name="node_count", default_value=node_count)
        pp_process_count_per_node = PipelineParameter(
            name="process_count_per_node", default_value=process_count_per_node)
        pp_run_invocation_timeout = PipelineParameter(
            name="run_invocation_timeout", default_value=run_invocation_timeout)
        pp_model_inference_parameters = PipelineParameter(
            name="model_inference_parameters", default_value=model_inference_parameters)

        # Set computation resources
        compute_target = ComputeTarget(
            workspace=workspace, name=cluster_name)

        # Create/update Inference environment from MLOPs
        environment = MLOCore.create_or_update_environment(
            workspace, environment_name, dockerfile, docker_args=None)

        # 4) Pipeline creation
        docker_source = mlops_source

        # Step 1. Load input data as dataset
        load_inference_step, load_inference_step_output = MLOPipelines.create_load_step(workspace, compute_target, environment_name,
                                                                                        pp_input_datastore, pp_input_filepath,
                                                                                        dockerfile, docker_source, inference_dataset_datatypes)
        # Step 2. Execute scoring
        execute_inference_step, execute_inference_step_output, execute_output_filename = MLOPipelines.create_execute_step(workspace, compute_target, environment_name,
                                                                                                                          pp_batch_size, pp_node_count, pp_process_count_per_node, pp_run_invocation_timeout,
                                                                                                                          load_inference_step_output, pp_model_name, pp_model_inference_parameters, pp_model_version,
                                                                                                                          dockerfile, dockerfile_source)

        # Step 3. Register input (prediction requests) dataset and output (predictions) dataset
        register_inference_step = MLOPipelines.create_register_step(workspace, compute_target, environment_name,
                                                                    execute_inference_step_output, execute_output_filename,
                                                                    load_inference_step_output, pp_output_inference_columns,
                                                                    docker_source)

        # Step 4. Save the predictions in the output folder specified in the pipeline
        save_inference_step = MLOPipelines.create_save_step(workspace, compute_target, environment_name,
                                                            execute_inference_step_output, execute_output_filename,
                                                            pp_output_datastore, pp_output_filepath, pp_output_inference_columns,
                                                            docker_source)

        # Link all steps and create the whole pipeline
        # execute_inference_step.run_after(register_inference_step)
        steps = [load_inference_step, execute_inference_step,
                 register_inference_step, save_inference_step]
        pipeline = Pipeline(workspace=workspace, steps=steps)

        # 5) Publish pipeline
        # See: https://docs.microsoft.com/es-es/python/api/azureml-pipeline-core/azureml.pipeline.core.publishedpipeline?view=azure-ml-py
        published_pipeline = pipeline.publish(
            name=pipeline_name,
            description=pipeline_description)
        # https://docs.microsoft.com/es-es/python/api/azureml-pipeline-core/azureml.pipeline.core.publishedpipeline?view=azure-ml-py
        # ,      version=1)

        return published_pipeline
