import os

from azureml.core import Workspace, Environment
from azureml.exceptions import WorkspaceException
from azureml.core.authentication import ServicePrincipalAuthentication

import mlflow
from azureml.core import Experiment
from azureml.core.run import Run
import logging
import sys
import traceback

# Logger (disabling)
# LOGGER = logging.getLogger(__name__)
# logging.basicConfig(
# stream=sys.stdout,
# level=logging.DEBUG
# )

class MLOCore:

    @staticmethod
    def get_workspace_with_authentication(subscription, resource_group,
                                          workspace_name, tenant_id,
                                          service_principal_id,
                                          service_principal_password):
        """Recover existing workspace from Azure ML with authentication

        It allows to obtain an Azure Workspace to interact with it. This
        function requires to pass authentication parameters belonging to an
        account (service principal account). It can recover workspace without
        having some hieritage o assume role mechinism as far as credentials
        are provided.
        Take care of this function as credentials (sensitive information) are
        passed as arguments. Think using KeyVault storage

        # Ref: https://docs.microsoft.com/es-es/python/api/azureml-core/azureml.core.authentication.serviceprincipalauthentication?view=azure-ml-py

        Args:
            subscription (string): Associated subscription with the
                Azure ML workspace
            resource_group (string): Associated resource group with the
                Azure ML workspace
            workspace_name (string): AzureML workspace name containing
                training artifacts
            tenant_id (string): tenant id with the service accounts belongs to
            service_principal_id (string): service prinicpal id
            service_principal_password: token key/password of the
                service principal.

        Raises:
            we: Exception reaised whenever the workspace doesn't exists

        Returns:
            Workspace: Existing workspace object
        """

        try:

            svc_pr = ServicePrincipalAuthentication(
                tenant_id=tenant_id,
                service_principal_id=service_principal_id,
                service_principal_password=service_principal_password)

            workspace = Workspace.get(workspace_name,
                                      resource_group=resource_group,
                                      subscription_id=subscription,
                                      auth=svc_pr)

            print(f"Using existing workspace {workspace_name}")

        except WorkspaceException as we:
            print(f'Error, there is no workspace with name {workspace_name}')
            print(we)
            raise we

        print(
            f"Using Workspace name={workspace.name}, \
                resource_group={workspace.resource_group}, \
                subscription_id={workspace.subscription_id}")

        return workspace

    @staticmethod
    def get_workspace(subscription, resource_group, workspace_name):
        """Recover existing workspace from Azure ML.

        Note: When request the workspace, authenticacion is None. In this case,
        credentials are recovered from Azure CLI login.
        @see https://docs.microsoft.com/en-us/python/api/azureml-core/azureml.core.workspace.workspace?view=azure-ml-py#azureml-core-workspace-workspace-create
        @see https://github.com/Azure/MachineLearningNotebooks/blob/master/how-to-use-azureml/manage-azureml-service/authentication-in-azureml/authentication-in-azureml.ipynb

        Args:
            subscription (string): Associated subscription with the
                Azure ML workspace
            resource_group (string): Associated resource group with the
                Azure ML workspace
            workspace_name (string): AzureML workspace name containing
                training artifacts



        Raises:
            we: Exception reaised whenever the workspace doesn't exists

        Returns:
            Workspace: Existing workspace object
        """

        try:

            workspace = Workspace.get(workspace_name,
                                      resource_group=resource_group,
                                      subscription_id=subscription)

            print(f'Using existing workspace "{workspace_name}"')

        except WorkspaceException as we:
            print(f'Error, there is no workspace with name {workspace_name}')
            print(we)
            raise we

        print(
            f"Using Workspace name={workspace.name}, \
                resource_group={workspace.resource_group}, \
                subscription_id={workspace.subscription_id}")

        return workspace

    @staticmethod
    def create_or_update_environment(workspace, name,
                                     docker_image, docker_args=None):
        """Create or update existing environment

        Args:
            workspace (Workspace): AzureML workspace object where the
                environment is going to create or reuse
            name (string): Environment name to create or update
            docker_image (string): Dockerfile containing train python
                extra libraries
            docker_args (object array, optional): (TODO) Review if it is
                required. Defaults to None.

        Returns:
            [type]: [description]
        """

        environment = None

        try:
            environment = Environment.get(workspace, name)
            print(f'Using existing environment "{name}"')
        except Exception as existing_environment:
            print("Checking if environment exists. It does not exists. Showing detailed exception response")
            print("".join(traceback.TracebackException.from_exception(existing_environment).format()))
            #raise register_exception
            # Create environment, as the exception is raised and it means that environment doesn't exists
            print(f'Creating new environment "{name}"')
            environment = Environment(name=name)

        # https://stackoverflow.com/questions/67387249/how-to-use-azureml-core-runconfig-dockerconfiguration-class-in-azureml-core-envi
        environment.python.user_managed_dependencies = True

        # Handle dockerfile vs image spec accordingly
        if os.path.exists(docker_image):
            environment.docker.base_dockerfile = docker_image
            environment.docker.base_image = None
            print("Validation of Docker image fine, Docker image exists")
        else:
            print(f"Error, path for dockerfile doesn't exists. \
                 Provided path [{docker_image}]")
            exit(1)

        if docker_args is not None:
            environment.docker.arguments = docker_args

        environment.python.user_managed_dependencies = True

        try:
            print("Registering new environment")
            environment = environment.register(workspace=workspace)
            print("New environment registered")
        except Exception as register_exception:
            print("Error registering new environment from amlops")
            print("".join(traceback.TracebackException.from_exception(register_exception).format()))
            raise register_exception

        return environment

    # Register metrics for the current execution
    @staticmethod
    def log_metric(name: str, value: float, mlflow: mlflow, run: Run):
        """[summary]

        Args:
            name (str): [description]
            value (float): [description]
            mlflow (mlflow): [description]
            run (Run): [description]
        """
        mlflow.log_metric(name, value)
        run.log('azml_' + name, value)

    @staticmethod
    def add_properties(properties, run):
        run.add_properties(properties)

    @staticmethod
    def end_training(mlflow, run):
        mlflow.end_run()
        run.complete()

    @staticmethod
    def start_training(mlflow):
        mlflow.start_run()
