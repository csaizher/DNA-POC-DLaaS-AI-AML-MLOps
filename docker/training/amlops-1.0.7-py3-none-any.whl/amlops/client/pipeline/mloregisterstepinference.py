from ...mlodata import MLOData

import argparse
from azureml.core import Run
import pandas as pd

from .mlopipelineutils import MLOPipelineUtils


class MLORegisterStepInference:

    """Contains execution code for the Register Step during Batch Inference.

    """
    @staticmethod
    def do_register_step():
        """Contains execution code for the Register Step during Batch Inference.
        """
        parser = argparse.ArgumentParser("register")

        # Information where to register data
        parser.add_argument("-ds", "--datastore", type=str,
                            help="Output datastore for the datasets registration",
                            dest='datastore')
        parser.add_argument("-drn", "--dataset-requests-name", type=str,
                            help="Registered dataset name for the prediction requests")
        parser.add_argument("-drd", "--dataset-requests-desc", type=str,
                            help="Registered dataset description for the prediction requests")
        parser.add_argument("-dpn", "--dataset-predictions-name", type=str,
                            help="Registered dataset name for the generated predictions")
        parser.add_argument("-dpd", "--dataset-predictions-desc", type=str,
                            help="Registered dataset description for the generated predictions")
        parser.add_argument("-dpin", "--dataset-predictions-input-name",
                            type=str, help="Input name used in the input step array")
        parser.add_argument("-dpifn", "--dataset-predictions-input-filename",
                            type=str, help="Source predictions filename")
        parser.add_argument("-dpifp", "--dataset-predictions-input-filepath",
                            type=str, help="Source predictions filepath")
        parser.add_argument("-drifp", "--dataset-requests-input-filename",
                            type=str, help="source request filename")
        parser.add_argument("-dpc", "--dataset-predictions-columns",
                            type=str, help="Header columns for the registered dataset")

        args = parser.parse_args()

        # Read output prediction columns for the dataset registration
        dataset_predictions_columns = MLOPipelineUtils.load_prediction_columns(
            args.dataset_predictions_columns)

        # Load as Panda Dataframe the predictions
        df_prediction_filepath = args.dataset_predictions_input_filepath + "/"\
            + args.dataset_predictions_input_filename

        df_predictions = pd.read_csv(df_prediction_filepath,
                                     sep=" ",
                                     header=None,
                                     names=dataset_predictions_columns)

        # Load as Dataset the input requests for predictions
        dataset = Run.get_context(
        ).input_datasets[args.dataset_predictions_input_name]
        df_requests = dataset.to_pandas_dataframe()

        # Read metadata for both dataset registration

        # Set names and descriptions
        ds_names = []
        ds_descs = []
        ds_names.append(args.dataset_requests_name)
        ds_descs.append(args.dataset_requests_desc)
        ds_names.append(args.dataset_predictions_name)
        ds_descs.append(args.dataset_predictions_desc)

        srcs = []
        srcs.append(df_requests)
        srcs.append(df_predictions)

        workspace = Run.get_context().experiment.workspace

        MLOData.register_df_multi(
            workspace=workspace,
            srcs=srcs,
            ds_names=ds_names,
            ds_descs=ds_descs,
            profiling=False)
