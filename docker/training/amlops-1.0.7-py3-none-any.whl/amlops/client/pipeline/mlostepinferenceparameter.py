class MLOStepInferenceParameter():
    """Pipeline parameter definition for the several inference steps.
    """

    def __init__(self, id: str, default_value: str):
        self.id = id
        self.defaul_value = default_value

    def name(self):
        """Returns the name of the Pipeline Parameter

        Returns:
            Name of the Pipeline Parameter
        """
        return self.id

    def default_value(self):
        """Returns the default value for the Pipeline Parameter

        Returns:
            Default value for the Pipeline Parameter
        """
        return self.defaul_value
