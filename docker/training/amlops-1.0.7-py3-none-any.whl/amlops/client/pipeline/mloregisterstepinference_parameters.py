from enum import Enum
from .mlostepinferenceparameter import MLOStepInferenceParameter


class MLORegisterStepInferenceParameters(Enum):
    """Pipeline parameters for the register inference step.

    Definition of the Pipeline parameters with their Ids and their
    default values.

    Values:
        DATASET_REQUEST_NAME ([MLOStepInferenceParameter]):
            Name of the dataset registered for the input inference data.
        DATASET_REQUEST_DESC ([MLOStepInferenceParameter]):
            Description of the dataset registered for the input
            inference data.
        DATASET_PREDICTIONS_NAME ([MLOStepInferenceParameter]):
            Name of the dataset registered for the ouput/predictions as
            a result of the inference.
        DATASET_PREDICTIONS_DESC ([MLOStepInferenceParameter]):
            Description of the dataset registered for the ouput/predictions
            as a result of the inference.
    """
    DATASET_REQUEST_NAME = MLOStepInferenceParameter(
        "dataset_request_name_param",
        "daas-lab-frc-dataset-inference-ai-001-use-case-inputs")
    DATASET_REQUEST_DESC = MLOStepInferenceParameter(
        "dataset_request_desc_param",
        "'Request input file for the inference model use case'")
    DATASET_PREDICTIONS_NAME = MLOStepInferenceParameter(
        "dataset_predictions_name_param",
        "daas-lab-frc-dataset-inference-ai-001-use-case-predictions")
    DATASET_PREDICTIONS_DESC = MLOStepInferenceParameter(
        "dataset_predictions_desc_param",
        "'Result of the inference for the use case model'")
