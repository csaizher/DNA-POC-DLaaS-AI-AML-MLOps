from azureml.core import Dataset
from azureml.core.model import Model

import argparse
import os
from ..mlodata import MLOData
from .mloclient import MLOClient

import mlflow

import sys
import gc
import zlib
import traceback
import pickle


class BaseTrain:

    """Base MLOps training class"""

    subscription = None
    resource_group = None
    run = None
    experiment = None
    workspace = None
    df_train_id = None
    df_test_id = None
    df_evaluation_id = None
    extra_params = None

    def __init__(self, subscription, resource_group, workspace_name, experiment_name, ds_train_id, ds_test_id, ds_evaluation_id, extra_params: dict = None):
        self.subscription = subscription
        self.resource_group = resource_group
        self.workspace_name = workspace_name
        self.experiment_name = experiment_name
        self.ds_train_id = ds_train_id
        self.ds_test_id = ds_test_id
        self.ds_evaluation_id = ds_evaluation_id
        self.run = None
        self.extra_params = extra_params

    def __init__(self, run, ds_train_id, ds_test_id, ds_evaluation_id, extra_params: dict = None):
        self.run = run
        self.ds_train_id = ds_train_id
        self.ds_test_id = ds_test_id
        self.ds_evaluation_id = ds_evaluation_id
        self.extra_params = extra_params

    def __init__(self, run):
        self.run = run
        self.__init_configuration()

    def __load_datasets(self):
        # Load and prepare train dataset
        df_train = None
        if self.ds_train_id is not None:
            df_train = MLOData.clean_df(Dataset.get_by_id(
                self.run.experiment.workspace, self.ds_train_id).to_pandas_dataframe())

        df_evaluation = None
        if self.ds_evaluation_id is not None:
            df_evaluation = MLOData.clean_df(Dataset.get_by_id(
                self.run.experiment.workspace, self.ds_evaluation_id).to_pandas_dataframe())

        df_test = None
        if self.ds_test_id is not None:
            df_test = MLOData.clean_df(Dataset.get_by_id(
                self.run.experiment.workspace, self.ds_test_id).to_pandas_dataframe())

        return df_train, df_test, df_evaluation

    def save_model(self, base_model, model_output_file: str = None, max_retries: int = 20):
        """ Persist the model object to local storage as a file validating that the model safety saved.

        Save the model object into local storage. Some errors has been detected when saving to disk and
        load later from AML Model Registry. So a basic "retry" mechanism has been implemented to ensure
        that the model is loaded safely. This mechanish tries to save and load the model to validate the
        persisted file. If the validation fails, it repeats the process until some "max_retries". The
        "max_retries" can be update. Also, a default output file storage folder is provided. This is 
        a convenient location for later model register process.

        TODO: Pending Error management, i.e. launch Exception when validations/retries are exhausted.

        Args:
            base_model (object): The model to be save locally
            model_output_file (str, optional): Local folder to save the model. Defaults to 
                self.getModelOutputFile().
            max_retries (int, optional): Number of retries if the validation fails. Defaults to 20.
        Raises:
            RuntimeError: [description]

        Returns:
            [type]: [description]
        """

        if model_output_file is None:
            model_output_file = self.getModelOutputFile()

        current_retries = 0
        save_ok = False

        while (not save_ok) and (current_retries < max_retries):

            try:
                with open(model_output_file, 'wb') as handle:
                    # Use pickle.DEFAULT_PROTOCOL instead of pickle.HIGHEST_PROTOCOL to maintain compatibility
                    # Issues have been found when importing from DSVM environment and the protocol was not the
                    # pickle.DEFAULT_PROTOCOL
                    pickle.dump(base_model, handle,
                                protocol=pickle.DEFAULT_PROTOCOL)
                with open(model_output_file, 'rb') as handle:
                    load_model_check = pickle.load(handle)
                print("Modelo load fine: " + str(load_model_check))
                del load_model_check
                gc.collect()
                save_ok = True

            except ValueError as v:
                print("Value error: " + str(v))
                traceback.print_exc()
            except zlib.error as e:
                print("Zlib error: " + str(e))
                print(sys.exc_info()[2])
                traceback.print_exc()
            except:
                print("Unexpected error:", sys.exc_info()[0])
                print("Unexpected error:", sys.exc_info()[2])
                print(sys.exc_info()[2])
                print("Iteración con error ["+str(current_retries)+"]")
                traceback.print_exc()
                current_retries = current_retries + 1

        print("Save model with success: " + str(save_ok) +
              " on retries: " + str(current_retries))

    # Utility function

    def getModelOutputFile(self):
        return "outputs/model/model.pkl"

    def getModelOutputDir(self):
        return "outputs/model"

    def setModelFramework(self, model_framework: Model.Framework):
        self.run.add_properties({"model_framework": model_framework})

    def setModelFrameworkVersion(self, model_framework_version):
        self.run.add_properties(
            {"model_framework_version": model_framework_version})

    def __init_configuration(self):
        """ Parses input data and recover required configuration """

        # Initialize parser
        info = "Train model"
        parser = argparse.ArgumentParser(description=info)
        subparsers = parser.add_subparsers(dest='command')

        train_model_parser = subparsers.add_parser("train-model")
        train_model_parser.add_argument(
            "-g", "--resource-group", help="Associated resource group with the Azure ML workspace", required=True)
        train_model_parser.add_argument(
            "-w", "--workspace-name", help="Workspace associted to the train", required=True)
        train_model_parser.add_argument(
            "-s", "--subscription", help="Associated subscription with the Azure ML workspace", required=True)
        train_model_parser.add_argument(
            "-e", "--experiment-name", help="Name of the experiment", required=True)
        train_model_parser.add_argument(
            "-m", "--model-name", help="Name of the physical model file", required=True)
        train_model_parser.add_argument(
            "-da", "--dataset-training", help="Registered dataset name fo training", required=False)
        train_model_parser.add_argument(
            "-dt", "--dataset-test", help="Description of the model to be registered", required=False)
        train_model_parser.add_argument(
            "-de", "--dataset-evaluation", help="Description of the model to be registered", required=False)

        # Parse arguments and add extra arguments for hyperparameter training or single training.
        # It builds the extra args of the model with the corrent type into a dict
        all_args = parser.parse_known_args()
        args = all_args[0]
        dynamic_args = all_args[1]
        dynamic_args_dict = MLOClient.update_args_hyperparameter_types(
            MLOClient.args_to_dict(dynamic_args))

        if args.command == 'train-model':

            # Create instance of DS implementation
            self.ds_train_id = args.dataset_training
            self.ds_test_id = args.dataset_test
            self.ds_evaluation_id = args.dataset_evaluation
            self.extra_params = dynamic_args_dict

    def do_train(self):

        # Link with mlflow
        mlflow.set_experiment(self.run.experiment.name)
        mlflow.set_tracking_uri(
            self.run.experiment.workspace.get_mlflow_tracking_uri())

        # Load and prepare train dataset
        df_train, df_test, df_evaluation = self.__load_datasets()

        # Create output directory for the model
        os.makedirs(self.getModelOutputDir(), exist_ok=True)

        # Invoke datascientist train implementation
        # Start mlflow run execution
        with mlflow.start_run():
            print("Starting user train method")
            self.train(self.run, mlflow, df_train, df_test,
                       df_evaluation, self.extra_params)
            print("Ending user train method")

    def train(self, run, mlflow, df_train, df_test, df_evaluation, extra_params):
        print("TODO: this method should be implemented. Training code goes here.")
