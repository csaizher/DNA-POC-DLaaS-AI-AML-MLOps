from enum import Enum

class MLOHypermetersConfigTypes(Enum):
    """Possible data types fot Hyperparameter configuration.

    Values:
        STRING ([str]): Config type to represent a hyperparameter which value type is a string.
        INTEGER ([str]): Config type to represent a hyperparameter which value type is an integer.
        FLOAT ([str]):  Config type to represent a hyperparameter which value type is a float.
        INVALID ([str]): Not valid data type.
    """    
    INVALID = 0
    STRING = 1
    INTEGER = 2
    FLOAT = 3

    @staticmethod
    def get(data: object):
        """Return associated MLOHypermetersConfigTypes according object input type.

        Checks valid types for MLOHypermetersConfigTypes and return the associated
        MLOHypermetersConfigTypes.

        Args:
            data (object): Object which type is tanking into an account to return 
                    associated MLOHypermetersConfigTypes

        Returns:
            MLOHypermetersConfigTypes: The MLOHypermetersConfigTypes associated to input 
                data or MLOHypermetersConfigTypes.INVALID if no valid type.
        """
        if isinstance( data, str):
            return MLOHypermetersConfigTypes.STRING
        elif isinstance( data, int):
            return MLOHypermetersConfigTypes.INTEGER
        elif isinstance( data, float):
            return MLOHypermetersConfigTypes.FLOAT
        else:
            return MLOHypermetersConfigTypes.INVALID

    @staticmethod
    def convert(type: str, data: str):
        """Convert input string to valid data type

        Convert input string to valid data type according
        Hyperparameter config type.

        Args:
            data (str): Input data to be converted from string
                to right datatype according "type" parameter
            type (str): Hyperparameter config type name. It can have
                HyperparameterConfigType.X.name values.
                Example:
                    MLOHypermetersConfigTypes.STRING.name == STRING
        Returns:
            Data object converted to right data type. It data is 'None' or type is
            not valid, 'None' is returned
            
        """
        if data is None:
            return None

        if type == MLOHypermetersConfigTypes.INTEGER.name:
            return int(data)
        elif type == MLOHypermetersConfigTypes.FLOAT.name:
            return float(data)
        elif type == MLOHypermetersConfigTypes.STRING.name:
            return data
        else:
            return None