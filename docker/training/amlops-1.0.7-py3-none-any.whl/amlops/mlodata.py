# Reference: https://techoverflow.net/2019/07/15/how-to-create-temporary-directory-in-python/
import tempfile
import shutil
from datetime import datetime

from azureml.core import Workspace, Experiment, Datastore, Dataset
from azureml.data import TabularDataset

from .mlocompute import MLOCompute
from .mlodata_constants import MLODataConstants

import re

# Only required to simulate dataset retrieval
import pandas as pd


class MLOData:

    @staticmethod
    def load_path_as_df(workspace, datastore_name, datastore_path_pattern, separator_type):
        """ Load data from AzureML Datastore workspace as a dataframe.

        Args:
            workspace (str): AzureML workspace identification
            datastore_name (str): AzureML datastore name containing the data to load
            datastore_path_pattern (str): AzureML datastore path pattern to match desired data

        Returns:
            df (Dataframe): Data from AzureML Datastore workspace as a dataframe.
        """

        # Connection to datastore
        datastore = Datastore.get(workspace, datastore_name=datastore_name)

        # Set file paths
        csv_paths = [(datastore, datastore_path_pattern)]

        # Dataframe creation
        tab_ds = Dataset.Tabular.from_delimited_files(path=csv_paths, header='NO_HEADERS', separator=separator_type,
                                                      encoding='utf8')
        df = tab_ds.to_pandas_dataframe(
            on_error='null', out_of_range_datetime='null')
        return df

    @staticmethod
    def list_files_path_as_array(workspace, datastore_name, datastore_file_path_arraylist_pattern):
        """ Load data from AzureML Datastore workspace as a dataframe.

        Args:
            workspace (str): AzureML workspace identification
            datastore_name (str): AzureML datastore name containing the data to load
            datastore_file_path_arraylist_pattern (str): AzureML datastore path pattern to match desired data

        Returns:
            files_list (ArrayList): Data from AzureML Datastore workspace as a arrayList.
        """

        # Connection to datastore
        datastore = Datastore.get(workspace, datastore_name=datastore_name)

        # Set file paths
        dataset = Dataset.File.from_files(
            path=[(datastore, datastore_file_path_arraylist_pattern)])
        # Consulta en formato lista los archivos
        files_list = dataset.to_path()

        return files_list

    @staticmethod
    def clean_df(df):
        """Remove extra fields or transformation performed when saved to AzureML Dataset

        Args:
            df ([type]): [description]

        Returns:
            [type]: [description]
        """
        # Remove date column as it was inserted for TimeSeries
        df = df.drop(columns=MLODataConstants.DATE)

        return df

    @staticmethod
    def register_files(workspace: Workspace,
                       train_src_path: str, test_src_path: str,
                       ds_train_name: str, ds_train_desc: str,
                       ds_test_name: str, ds_test_desc: str,
                       target_path=None,
                       datastore_name: str =
                       MLODataConstants.DATASETS_DATASTORE_NAME):
        """ Register dataset into AzureML workspace as file dataset from local files.

        Save train dataset and test dataset into AzureML datastore and
        register both datasets as AzureML datasets with a version.

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML
                components
            path_train_files ([type]): [description]
            path_test_files ([type]): [description]
            ds_train_name (str): Train dataset name used for dataset
                registration
            ds_train_desc (str): [description]
            ds_test_name (str): Test dataset name used for dataset registration
            ds_test_desc (str): [description]
            target_path ([type], optional): [description]. Defaults to None.
            datastore_name (str, optional): [description]. Defaults to
                MLODataConstants.DATASETS_DATASTORE_NAME.

        Raises:
            RuntimeError: [description]

        Returns:
            [type]: [description]
        """

        # Load datastore reference
        datastore = Datastore.get(workspace, datastore_name)

        # Get destination paths on datastore
        train_dst_path = MLOData.__resolve_dataset_destination_path(
            workspace, ds_train_name, target_path)
        test_dst_path = MLOData.__resolve_dataset_destination_path(
            workspace, ds_test_name, target_path)

        # Save dataset on Datastore (files)
        train_files = MLOData.__save_files(
            datastore, train_dst_path, train_src_path)
        test_files = MLOData.__save_files(
            datastore, test_dst_path, test_src_path)

        # Recover data as Datasets for Azure Dataset Registration
        ds_train = Dataset.File.from_files(path=train_files)
        ds_test = Dataset.File.from_files(path=test_files)

        # Do registration
        return MLOData.__register_dataset_training(workspace, ds_train, ds_train_name, ds_train_desc, ds_test, ds_test_name, ds_test_desc)

    @staticmethod
    def register_df_with_evaluation(workspace: Workspace,
                                    train_src, test_src, evaluation_src,
                                    ds_train_name: str, ds_train_desc: str,
                                    ds_test_name: str, ds_test_desc: str,
                                    ds_evaluation_name: str,
                                    ds_evaluation_desc: str,
                                    profiling: bool = False,
                                    target_path=None,
                                    datastore_name: str =
                                    MLODataConstants.DATASETS_DATASTORE_NAME):
        """ Register dataset into AzureML workspace as TimeSeries from dataframe.

        Save train dataset and test dataset into AzureML datastore and register both datasets
        as AzureML datasets with a version.  

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML components
            train_src ([type]): [description]
            test_src ([type]): [description]
            ds_train_name (str): Train dataset name used for dataset registration
            ds_train_desc (str): [description]
            ds_test_name (str): Test dataset name used for dataset registration
            ds_test_desc (str): [description]
            ds_evaluation_src ([type]): [description]
            ds_evaluation_name (str): Evaluation dataset name used for dataset registration
            ds_evaluation_desc (str): [description]
            profiling (bool): Decide to do or not a profiling on data
            target_path (str, optional): Override datapath where datasources are persisted. Defaults to None.
            datastore_name (str, optional): Datastore where the datasets are stored. Defaults to MLODataConstants.DATASETS_DATASTORE_NAME.

        Raises:
            RuntimeError: [description]

        Returns:
            [type]: [description]
        """

        # Load datastore reference
        datastore = Datastore.get(workspace, datastore_name)

        # Get destination paths on datastore
        train_dst_path = MLOData.__resolve_dataset_destination_path(
            workspace, ds_train_name, target_path)
        test_dst_path = MLOData.__resolve_dataset_destination_path(
            workspace, ds_test_name, target_path)

        # Save dataset on Datastore (dataframes)
        # Perform data drit preparation adding "date" column
        train_src = train_src.assign(date=datetime.utcnow())
        test_src = test_src.assign(date=datetime.utcnow())
        # Vaidate column names
        MLOData.__validate_columns(train_src.columns)
        MLOData.__validate_columns(test_src.columns)

        # Save dataset on Datastore
        train_files = MLOData.__save_dataframe(
            datastore, train_dst_path, train_src)
        test_files = MLOData.__save_dataframe(
            datastore, test_dst_path, test_src)

        # Recover data as Datasets for Azure Dataset Registration
        ds_train = Dataset.Tabular.from_parquet_files(path=train_files)
        ds_test = Dataset.Tabular.from_parquet_files(path=test_files)

        ds_train = ds_train.with_timestamp_columns(MLODataConstants.DATE)
        ds_test = ds_test.with_timestamp_columns(MLODataConstants.DATE)

        evaluation_dst_path = MLOData.__resolve_dataset_destination_path(
            workspace, ds_evaluation_name, target_path)

        # Perform data drit preparation adding "date" column
        evaluation_src = evaluation_src.assign(date=datetime.utcnow())
        # Validate column names
        MLOData.__validate_columns(evaluation_src.columns)
        # Save dataset on Datastore
        evaluation_files = MLOData.__save_dataframe(
            datastore, evaluation_dst_path, evaluation_src)
        # Recover data as Datasets for Azure Dataset Registration
        ds_evaluation = Dataset.Tabular.from_parquet_files(
            path=evaluation_files)
        ds_evaluation = ds_evaluation.with_timestamp_columns(
            MLODataConstants.DATE)

        # Do registration
        return MLOData.__register_dataset_training(workspace, profiling, ds_train, ds_train_name, ds_train_desc, ds_test, ds_test_name, ds_test_desc, ds_evaluation, ds_evaluation_name, ds_evaluation_desc)

    @staticmethod
    def register_df_multi(
            workspace: Workspace,
            srcs: list,
            ds_names: list,
            ds_descs: list,
            profiling: bool = False,
            target_path=None,
            datastore_name: str = MLODataConstants.DATASETS_DATASTORE_NAME):
        """ Register multiple dataframes into AML workspace as TimeSeries
            datasets from pandas dataframes.

            Save multiples datasets into AzureML datastore and register all
            datasets as AzureML datasets with same version.

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure
                ML components
            profiling (bool): Decide to do or not a profiling on data
            srcs (list): List of input dataframes to be registered
            ds_names (str): List of names associated to input source
                dataframes. Defaults to None.
            ds_descs (str): List of descriptions associated to input source
                dataframes. Defaults to None.
            target_path (str, optional): Override datapath where datasources
                are persisted. Defaults to None.
            datastore_name (str, optional): Datastore where the datasets are
                stored. Defaults to MLODataConstants.DATASETS_DATASTORE_NAME.

        Raises:
            RuntimeError: [description]

        Returns:
            [type]: [description]
        """

        # Load datastore reference
        datastore = Datastore.get(workspace, datastore_name)

        # Initialize current version
        current_version = None

        # Get destination paths on datastore
        dst_paths = []
        for current_src, src in enumerate(srcs):

            ds_name = ds_names[current_src]
            ds_desc = ds_descs

            # Get destination paths on datastore
            dst_path = MLOData.__resolve_dataset_destination_path(
                workspace, ds_name, target_path)
            dst_paths.append(dst_path)

            # Save dataset on Datastore (dataframes)
            # Perform data drit preparation adding "date" column
            src = src.assign(date=datetime.utcnow())

            # Validate column names
            MLOData.__validate_columns(src.columns)

            # Save dataset on Datastore
            files = MLOData.__save_dataframe(datastore, dst_path, src)

            # Recover data as Datasets for Azure Dataset Registration
            ds = Dataset.Tabular.from_parquet_files(path=files)
            ds = ds.with_timestamp_columns(MLODataConstants.DATE)

            # Do registration
            current_version = MLOData.__register_dataset(
                workspace, profiling, ds, ds_name, ds_desc)

        return current_version

    @staticmethod
    def register_df(workspace: Workspace,
                    train_src, test_src,
                    ds_train_name: str, ds_train_desc: str,
                    ds_test_name: str, ds_test_desc: str,
                    profiling: bool = False,
                    target_path=None,
                    datastore_name: str =
                    MLODataConstants.DATASETS_DATASTORE_NAME):
        """ Register dataset into AzureML workspace as TimeSeries from dataframe.

        Save train dataset and test dataset into AzureML datastore and register both datasets
        as AzureML datasets with a version.  

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML components
            profiling (bool): Decide to do or not a profiling on data
            train_src ([type]): [description]
            test_src ([type]): [description]
            ds_train_name (str): Train dataset name used for registration
            ds_train_desc (str): Train dataset description used for registration
            ds_test_name (str): Test dataset name used for registration
            ds_test_desc (str): Test dataset description used for registration
            target_path ([type], optional): [description]. Defaults to None.
            datastore_name (str, optional): [description]. Defaults to MLODataConstants.DATASETS_DATASTORE_NAME.

        Raises:
            RuntimeError: [description]
            RuntimeError: [description]

        Returns:
            [type]: [description]
        """

        # Load datastore reference
        datastore = Datastore.get(workspace, datastore_name)

        # Get destination paths on datastore
        train_dst_path = MLOData.__resolve_dataset_destination_path(
            workspace, ds_train_name, target_path)
        test_dst_path = MLOData.__resolve_dataset_destination_path(
            workspace, ds_test_name, target_path)

        # Save dataset on Datastore (dataframes)
        # Perform data drit preparation adding "date" column
        train_src = train_src.assign(date=datetime.utcnow())
        test_src = test_src.assign(date=datetime.utcnow())
        # Validate column names
        MLOData.__validate_columns(train_src.columns)
        MLOData.__validate_columns(test_src.columns)

        # Save dataset on Datastore
        train_files = MLOData.__save_dataframe(
            datastore, train_dst_path, train_src)
        test_files = MLOData.__save_dataframe(
            datastore, test_dst_path, test_src)

        # Recover data as Datasets for Azure Dataset Registration
        ds_train = Dataset.Tabular.from_parquet_files(path=train_files)
        ds_test = Dataset.Tabular.from_parquet_files(path=test_files)

        ds_train = ds_train.with_timestamp_columns(MLODataConstants.DATE)
        ds_test = ds_test.with_timestamp_columns(MLODataConstants.DATE)

        # Do registration
        return MLOData.__register_dataset_training(workspace, profiling, ds_train, ds_train_name, ds_train_desc, ds_test, ds_test_name, ds_test_desc, None, None, None)

    @staticmethod
    def __generate_data_profiling(workspace, ds):

        # Create a name for the experiment in charge of calculate profiling
        experiment_name = ds.name + "-profile"
        experiment = Experiment(workspace=workspace, name=experiment_name)

        # Create compute resources
        compute_target = MLOCompute.get_profile_compute(workspace)

        # Generate profile
        # @See https://docs.microsoft.com/en-us/python/api/azureml-core/azureml.data.tabulardataset?view=azure-ml-py#submit-profile-run-compute-target--experiment-
        ds.submit_profile_run(
            compute_target=compute_target, experiment=experiment)

    @staticmethod
    def load_df_raw(workspace: Workspace, ds_train_name: str, ds_test_name: str, ds_evaluation_name: 'None', version: str = 'latest'):
        """ Load dataset and return it as DF without filtering internal fields.

        Load a registered AzureML dataset and return into a panda dataframe. Internal fields,
        such as "date", used for TimeSeries, are not removed.  

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML components
            ds_train_name (str): Train dataset name used for dataset loading
            ds_test_name (str): Test dataset name used for dataset loading
            ds_evaluation_name (str): Evaluation dataset name used for dataset loading
            version (str): dataset version

        Returns:
            dataframe: Panda dataframe contining the dataset.

        """

        ds_train = MLOData.__load_df(workspace, ds_train_name, version)
        ds_test = MLOData.__load_df(workspace, ds_test_name, version)

        if ds_evaluation_name is not None:
            ds_evaluation = MLOData.__load_df(
                workspace, ds_evaluation_name, version)
            return ds_train, ds_test, ds_evaluation
        else:
            return ds_train, ds_test

    @staticmethod
    def load_df(workspace: Workspace, ds_train_name: str, ds_test_name: str, version: str = 'latest'):
        """ Load dataset and return it as DF filtering internal fields.

        Load a registered AzureML dataset and return into a panda dataframe. Internal fields,
        such as "date", used for TimeSeries, are removed.  

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML components
            ds_train_name (str): Train dataset name used for dataset loading
            ds_test_name (str): Test dataset name used for dataset loading
            version (str): dataset version

        Returns:
            dataframe: Panda dataframe containing the dataset.

        """

        ds_train, ds_test = MLOData.load_df_raw(
            workspace, ds_train_name, ds_test_name, None, version)

        # Remove date column as it was inserted for TimeSeries
        ds_train = ds_train.drop(columns=MLODataConstants.DATE)
        ds_test = ds_test.drop(columns=MLODataConstants.DATE)

        return ds_train, ds_test

    @staticmethod
    def load_df(workspace: Workspace, ds_name: str, version: str = 'latest'):
        """ Load specific dataset and return it as DF filtering internal fields.

        Load a registered AzureML dataset and return into a panda dataframe. Internal fields,
        such as "date", used for TimeSeries, are removed.  

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML components
            ds_name (str): The dataset name used registered in the platform
            version (str): dataset version

        Returns:
            dataframe: Panda dataframe containing the dataset.

        """

        ds = MLOData.__load_df(workspace, ds_name, version)

        # Remove date column as it was inserted for TimeSeries
        ds = ds.drop(columns=MLODataConstants.DATE)

        return ds

    @staticmethod
    def load_df_with_evaluation(workspace: Workspace, ds_train_name: str, ds_test_name: str, ds_evaluation_name: str, version: str = 'latest'):
        """ Load dataset and return it as DF filtering internal fields.

        Load a registered AzureML dataset and return into a panda dataframe. Internal fields,
        such as "date", used for TimeSeries, are removed.  

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML components
            ds_train_name (str): Train dataset name used for dataset loading
            ds_test_name (str): Test dataset name used for dataset loading
            version (str): dataset version

        Returns:
            dataframe: Panda dataframe containing the dataset.

        """

        ds_train, ds_test, ds_evaluation = MLOData.load_df_raw(
            workspace, ds_train_name, ds_test_name, ds_evaluation_name, version)

        # Remove date column as it was inserted for TimeSeries
        ds_train = ds_train.drop(columns=MLODataConstants.DATE)
        ds_test = ds_test.drop(columns=MLODataConstants.DATE)
        ds_evaluation = ds_evaluation.drop(columns=MLODataConstants.DATE)

        return ds_train, ds_test, ds_evaluation

    @staticmethod
    def __load_df(workspace: Workspace, ds_name: str, version: str = 'latest'):

        try:
            dataset = Dataset.get_by_name(workspace, ds_name, version=version)
        except:
            raise RuntimeError(
                'Error loading Dataset, name o version are wrong')

        if isinstance(dataset, TabularDataset):
            return dataset.to_pandas_dataframe()
        else:
            # Load from files
            return MLOData.__load_df_from_files(dataset)

    @staticmethod
    def __load_df_from_files(dataset):

        # Create temporal folder for intermediate files
        tmp_dataset_path = tempfile.mkdtemp(prefix="mlops-ds-tmp-")

        # Download CSV files from
        try:
            files = dataset.download(
                target_path=tmp_dataset_path, overwrite=True)

            df = []
            for file in files:
                df.append(pd.read_csv(file))

            # Delete temporary files
            shutil.rmtree(tmp_dataset_path)

            # Return Dataframe
            return df
        except:

            # Delete temporary files
            shutil.rmtree(tmp_dataset_path)

            raise RuntimeError('Error downloading Datasets from local')

    @staticmethod
    def load_files(workspace: Workspace, ds_train_name: str, ds_test_name: str, version: str = 'latest', pathLocal=None):
        """ Load dataset and save as local files.

        Load dataset and save as local files using the default datastore. 

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML components
            ds_train_name (str): Train dataset name used for dataset loading
            ds_test_name (str): Test dataset name used for dataset loading
            version (str): dataset version
            pathLocal (str): local path to save dataset files

        Raises:
            RuntimeError: Dataset with name and version doesn't exists
            RuntimeError: Failed to downloading files to local path
            RuntimeError: Path local is not defined

        Returns:
            None

        """

        if pathLocal is None:
            raise RuntimeError('Error, no local path is defined')

        datastore = workspace.get_default_datastore()
        try:
            data_train = Dataset.get_by_name(
                workspace, ds_train_name, version=version)
            data_test = Dataset.get_by_name(
                workspace, ds_test_name, version=version)
        except:
            raise RuntimeError(
                'Error loading Dataset, name o version are wrong')

        try:
            data_train.download(target_path=pathLocal, overwrite=True)
            data_test.download(target_path=pathLocal, overwrite=True)
        except:
            raise RuntimeError('Error downloading Datasets from local')

    @staticmethod
    def __resolve_dataset_destination_path(workspace: Workspace, dataset_name: str, target_path: str = None):
        """ Figure out the destination path on an Azure ML Datastore for a dataset.

        Resolve the destination path that a dataset must be uploaded according their last version, their name, the
        target dataset and an additional target path (optional). Datastore is not required as the datastore is 
        resolved when an specific Dataset search by name has done.

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML components
            dataset_name (str): [description]
            target_path (str, optional): Overrided target path. Defaults to None.
        """

        # Get current version
        try:
            version = Dataset.get_by_name(
                workspace, dataset_name, version='latest').version
        except:
            version = 0

        # Calculate destination path on blobstorage with the pattern: dataset/<nombreDataset>/version_<nVersion>/
        if target_path is not None:
            path = target_path
        else:
            path = "/".join([MLODataConstants.DATASETS_ROOT_PATH,
                            dataset_name,
                            MLODataConstants.DATASETS_PATH_VERSION_PREFIX
                            + str(int(version + 1))])

        return path

    @staticmethod
    def __save_files(datastore: Datastore, dst_path: str, src_path: str):

        # Upload all files that composes the train and the test datasets
        # nombre_ficheros = path_fichero_local[path_fichero_local.rfind('/'):]
        folders_names = []
        files = []
        for p in src_path:
            f = p[p.rfind('/')+1:]
            folders_names.append(f)
            files.append((datastore, dst_path + '/' + f))

        # Upload into datastore/blobstorage
        try:
            datastore.upload_files(files=src_path, target_path=dst_path)
        except:
            raise RuntimeError('Error al subir los ficheros al Storage')

        return files

    @staticmethod
    def __save_dataframe(datastore: Datastore, dst_path: str, src):
        """ Save dataframe to local and then upload to datastore

        A date column is added in order to register as a Tabular TimeSeries Dataset
        for doing Datadrift from AzureML    

        Raises:
            RuntimeError: Not able to upload to Datastore

        """

        # Create temporal folder for intermediate files
        tmp_parquet_src_path = tempfile.mkdtemp(prefix="mlops-ds-tmp-")

        # Save as parquet file for both cases
        tmp_parquet_src_file = tmp_parquet_src_path+"/"+'ds.parquet'
        src.to_parquet(path=tmp_parquet_src_file,
                       index=False, partition_cols=None)

        # Upload to datastore
        files = MLOData.__save_files(
            datastore, dst_path, [tmp_parquet_src_file])

        # Remove temporal folders
        shutil.rmtree(tmp_parquet_src_path)

        return files

    @staticmethod
    def __validate_columns(columns: list):
        """Check Dataframe columns are not allowed by Parquet files.

        Parquet format is used when persisting Dataframes. Parquet has some
        restrictions on column names. This methods validates that restricted
        characters are not used.

        Args:
            columns (list): List of columns containing column names to validate

        Raise:
            Exception: Whenever some column is not valid
        """
        regex = r"[ ,;{}()\n\t=]+"

        for column in columns:
            any_match = re.search(regex, column)

            if any_match:
                raise Exception(
                    "Error, column with name [" + column + "] has an invalid characters.")

    @staticmethod
    def __register_dataset(workspace: Workspace, profiling: bool,
                           ds: Dataset, ds_name: str, ds_desc: str):
        """Registers a single dataset

        Register a single dataset into Azure ML Dataset registry. Also allows the
        generation dataset profiling if "profiling" parameter is true.

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML dataset registry
            ds (Dataset): Azure Dataset to be registered
            ds_name (str): Name of the dataset for the dataset registration
            ds_train_desc (str): Description of the dataset for the dataset registration
            profiling (bool): If true, it generates dataset profiling (data statistics) otherwise
                  ignore profiling.
                  @See https://docs.microsoft.com/en-us/python/api/azureml-core/azureml.core.dataset.dataset?view=azure-ml-py#generate-profile-compute-target-none--workspace-none--arguments-none-

        Raises:
            RuntimeError: [description]

        Returns:
            [type]: [description]
        """

        # Register Datasets
        try:
            ds_registered = ds.register(
                workspace, name=ds_name, description=ds_desc, create_new_version=True)

            # Generate profile for training if required
            if profiling:
                MLOData.__generate_data_profiling(workspace, ds_registered)

            # Both datasets should have the same version
            return ds_registered.version
        except:
            raise RuntimeError(
                'Error registering datasets with name [' + ds_name + ']')

    @staticmethod
    def __register_dataset_training(workspace: Workspace,
                                    profiling: bool,
                                    ds_train: Dataset, ds_train_name: str, ds_train_desc: str,
                                    ds_test: Dataset, ds_test_name: str, ds_test_desc: str,
                                    ds_evaluation=None, ds_evaluation_name: str = None, ds_evaluation_desc: str = None):
        """Register training datasets.

        Register training datasets at the same time. Training datasets include training 
        dataset and also evaluation/test datasets

        Args:
            workspace (Workspace): Azure ML workspace to interact with Azure ML components
            ds_train (Dataset): Training Azure Dataset to be registered
            ds_train_name (str): Name of the training dataset for the dataset registration
            ds_train_desc (str):  Description of the training dataset for the dataset registration
            ds_test (Dataset): Test Azure Dataset to be registered
            ds_test_name (str): Name of the test dataset for the dataset registration
            ds_test_desc (str): Description of the test dataset for the dataset registration
            ds_evaluation ([type], optional): Evaluation Azure Dataset to be registered. Defaults to None.
            ds_evaluation_name (str, optional): Name of the evaluation dataset for the dataset registration. Defaults to None.
            ds_evaluation_desc (str, optional): Description of the evaluation dataset for the dataset registration. Defaults to None.
            profiling (bool): If true, it generates dataset profiling (data statistics) otherwise
                  ignore profiling.
                  @See https://docs.microsoft.com/en-us/python/api/azureml-core/azureml.core.dataset.dataset?view=azure-ml-py#generate-profile-compute-target-none--workspace-none--arguments-none-


        Raises:
            RuntimeError: [description]

        Returns:
            [type]: [description]
        """

        # Register Datasets
        try:
            ds_train_registered = ds_train.register(
                workspace, name=ds_train_name, description=ds_train_desc, create_new_version=True)
            ds_test.register(workspace, name=ds_test_name,
                             description=ds_test_desc, create_new_version=True)

            if ds_evaluation is not None:
                ds_evaluation.register(workspace, name=ds_evaluation_name,
                                       description=ds_evaluation_desc, create_new_version=True)

            # Generate profile for training if required
            if profiling:
                MLOData.__generate_data_profiling(
                    workspace, ds_train_registered)

            # Both datasets should have the same version
            return ds_train_registered.version
        except:
            raise RuntimeError('Error registering datasets')
