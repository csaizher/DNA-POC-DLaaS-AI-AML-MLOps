"""
Global amlops exception and warning classes.
"""


class MLOException(Exception):
    """Base exception class for amlops exceptions"""

    pass


class MLOTrainingConfigurationException(MLOException):
    """Base exception class for training configuration file problems"""
    pass
