

class MLODataConstants:
    """Constants used for the MLOData module.

    Values:
        DATE ([str]): Date/timestamp column string identifier added to
            registered datasets to allow the creation of Tabular
            Time Series just to work with data-drift.
        DATASETS_DATASTORE_NAME ([str]): Datastore in charge of keeping
            datasets for the AML environment.
        DATASETS_ROOT_PATH ([str]):  Root path for dataset registration
        DATASETS_PATH_VERSION_PREFIX ([str]): PREFIX used to save dataset
            on storage when calculate destination path
    """
    DATE = 'date'
    DATASETS_DATASTORE_NAME = "aml_application_data"
    DATASETS_ROOT_PATH = "dataset"
    DATASETS_PATH_VERSION_PREFIX = "version_"
