from azureml.core.workspace import Workspace
from azureml.core.model import Model


class MLOUtils():
    """Support funtions used for the other modules.
    """

    @staticmethod
    def test_aml_connection(subscription_id: str,  resource_group: str,
                            workspace: str):
        """Do simple operation to test workspaces access

        Execute a simple operation to test workspace access

        Args:
            subscription (string): Associated subscription with the Azure ML
                 workspace
            resource_group (string): Associated resource group with the Azure
                 ML workspace
            workspace_name (string): AzureML workspace name to test connection

        Raises:
            ValueError: some or all of the inputs are None
            Exception: Access to workspace cannot be achieved.

        """

        if subscription_id is None:
            raise ValueError(
                'Error testing workspace access, subscription cannot be None')

        if resource_group is None:
            raise ValueError(
                'Error testing workspace access, resource group cannot be \
                 None')

        if workspace is None:
            raise ValueError('Error testing workspace access, workspace name \
                             cannot be None')

        try:
            workspace = Workspace.get(
                name=workspace,
                subscription_id=subscription_id,
                resource_group=resource_group)
        except Exception as e:
            print("Error when trying to access to workspace")
            raise(e)
        else:
            print("Workspace access reached")

        try:
            models = Model.list(workspace, latest=True)
            print("Models retrieved successfully")
            print(models)
        except Exception as e:
            print("Error when trying to list models")
            raise(e)
