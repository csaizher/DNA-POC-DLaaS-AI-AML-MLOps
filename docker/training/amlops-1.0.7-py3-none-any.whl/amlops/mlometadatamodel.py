# Reference: https://techoverflow.net/2019/07/15/how-to-create-temporary-directory-in-python/
import tempfile
import shutil
import glob
import pickle

# Requerido para carga de datos de la plataforma DaaS Data
from azureml.core.model import Model


class MLOMetadataModel():
    """Support funtions used for the other modules.
    """

    @staticmethod
    def update_model_tag(workspace, model_name, model_tag_update_pattern):

        # Añadir o actualizar la etiqueta de un modelo
        model = Model(workspace, model_name)
        model.update_tags_properties(add_tags=model_tag_update_pattern)
        print("Model tags updated")

    @staticmethod
    def remove_model_tag(workspace, model_name, model_remove_tag_pattern):

        # Borrar la etiqueta asignada a un modelo
        model = Model(workspace, model_name)
        model.update_tags_properties(remove_tags=model_remove_tag_pattern)
        print("Model tags removed")

    @staticmethod
    def update_model_properties(workspace, model_name,
                                model_properties_update_pattern):

        # Borrar la etiqueta asignada a un modelo
        model = Model(workspace, model_name)
        model.update_tags_properties(
            add_properties=model_properties_update_pattern)
        print("Model properties updated")

    @staticmethod
    def list_model_by_tag(workspace, model_name, model_list_tag_pattern):

        # Listar modelos filtrados por etiqueta/s
        model = Model(workspace, model_name)
        model_tag_list = model.list(workspace, name=model_name,
                                    tags=model_list_tag_pattern, latest=False)
        print("Model tag listed")
        return model_tag_list

    @staticmethod
    def promote_stage_to_training(workspace, model_name, version):

        # Actualizar la etiqueta de estado a 'training'
        model = Model(workspace, model_name, version=version)
        if model.tags == {}:
            model.update_tags_properties(add_tags={'stage': 'training'})
            print("Changing model" + model_name + "stage to 'training'")
        else:
            print("No tag changes")

    @staticmethod
    def promote_stage_to_assesment(workspace, model_name, model_version):

        # Actualizar la etiqueta de estado a 'assesment'
        model = Model(workspace, model_name, version=model_version)
        if model.tags == {'stage': 'training'}:
            model.update_tags_properties(add_tags={'stage': 'assesment'})
            print("Changing model" + model_name + "stage to 'assesment'")
        else:
            print("No tag changes")

    @staticmethod
    def promote_stage_to_qa(workspace, model_name, model_version):

        # Actualizar la etiqueta de estado a 'qa'
        model = Model(workspace, model_name, version=model_version)
        if model.tags == {'stage': 'assesment'}:
            model.update_tags_properties(add_tags={'stage': 'qa'})
            print("Changing model" + model_name + "stage to 'qa'")
        else:
            print("No tag changes")

    @staticmethod
    def promote_stage_to_production(workspace, model_name, model_version):

        # Actualizar la etiqueta de estado a 'production'
        model = Model(workspace, model_name, version=model_version)
        if model.tags == {'stage': 'qa'}:
            model.update_tags_properties(add_tags={'stage': 'production'})
            print("Changing model" + model_name + "stage to 'production'")
        else:
            print("No tag changes")

    @staticmethod
    def deprecate_stage_to_archived(workspace, model_name, model_version):

        # Actualizar la etiqueta de estado a 'archived'
        model = Model(workspace, model_name, version=model_version)
        model.update_tags_properties(add_tags={'stage': 'archived'})
        print("Deprecating model" + model_name + "stage to 'archived'")

    @staticmethod
    def archive_deprecated_model_versions(workspace, model_name):

        # Actualizar la etiqueta de estado  de versiones antiguas de los modelos a 'archived'
        model = Model(workspace, model_name)
        last_version = model.version
        for v in range(1, last_version):
            try:
                modelvx = Model(workspace, model_name, version=v)
                modelvx.update_tags_properties(add_tags={'stage': 'archived'})
                print("Deprecating model" + model_name +
                      "old versions stage to 'archived'")

            except Exception:
                print("Deprecating next model" + model_name +
                      "old versions stage to 'archived'")

    @staticmethod
    def delete_deprecated_model_versions(workspace, model_name, max_deprecated_versions_alive):
        model = Model(workspace, model_name)
        last_version = model.version
        min_deprecated_version_alive = last_version - max_deprecated_versions_alive
        for v in range(1, min_deprecated_version_alive):
            try:
                modelvx = Model(workspace, model_name, version=v)
                modelvx.delete()
                print("Deleting model" + model_name + "deprecated versions")

            except Exception:
                print("Deprecating next model" +
                      model_name + "deprecated versions")

    @staticmethod
    def load_model_to_assesment(workspace, model_name, model_version):

        # Set model as in assessment stage
        MLOMetadataModel.promote_stage_to_assesment(
            workspace, model_name, model_version)

        # Recover model from Azure ML Model Registry
        model = Model(workspace, model_name, version=model_version)

        # Create temporal folder for intermediate model pkl
        tmp_model_path = tempfile.mkdtemp(prefix="mlops-model-tmp-")

        # Download CSV files from
        model.download(target_dir=tmp_model_path, exist_ok=True)

        # Load model into memory
        glo = glob.glob(tmp_model_path+'/*')
        model_filepath = ''.join(glo)
        with open(model_filepath, 'rb') as handle:
            loaded_model = pickle.load(handle)

        # Delete temporary files
        shutil.rmtree(tmp_model_path)

        # Return the loaded model
        return loaded_model
